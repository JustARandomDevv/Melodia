# Melodia on Linux Mint (Cinnamon)

`main.py` is **unchanged** — same file, same logic, byte-for-byte identical to what you
uploaded. Everything here is just the Linux-side plumbing (system libraries, a launcher,
a venv) to get that exact script running under Cinnamon.

## Quick start

```bash
chmod +x install.sh install-launcher.sh run.sh
./install.sh              # installs system + Python dependencies into .venv
./install-launcher.sh      # adds Melodia to your Cinnamon applications menu
```

After that, launch Melodia from the Cinnamon menu like any other app, or run it directly:

```bash
./run.sh
```

## What `install.sh` actually installs, and why

| Package | Why `main.py` needs it |
|---|---|
| `python3-gi`, `gir1.2-gtk-3.0`, `gir1.2-webkit2-4.1` | `pywebview` renders its window using GTK/WebKit on Linux — this is the backend it picks automatically, no code change required |
| `ffmpeg` | `yt-dlp` needs it to extract/convert audio to mp3; `mutagen` reads the resulting mp3 tags |
| `gir1.2-appindicator3-0.1` (or the `ayatana` variant) | Cinnamon uses AppIndicators for tray icons instead of the older systray protocol — `pystray` needs this to display the tray icon at all |
| Python packages in `requirements.txt` | `webview`, `PIL`, `ytmusicapi`, `pygame`, `yt_dlp`, `mutagen`, plus the optional `keyboard`/`pystray`/`pypresence` the script already guards with `try/except` |

The script installs into a virtual environment (`.venv`) created with
`--system-site-packages`, so it can see the apt-installed GTK bindings (which aren't
available via pip) while keeping everything else isolated.

## Two things that behave differently on Linux (not code changes — just how these libraries work on this OS)

**Global media keys (`keyboard` module).** On Linux, this library reads raw input
devices, which normally requires root. If you run `./run.sh` as a regular user, media-key
hooking may silently fail to register (the app already wraps this in `try/except`, so it
won't crash — the keys just won't do anything). If you want them working, either run once
as root to test, or add your user to the `input` group and re-login:
```bash
sudo usermod -aG input $USER
```
then log out/in. Depending on your distro's udev rules this may or may not be enough —
it's a known rough edge of the `keyboard` package on Linux in general, not something
specific to this script.

**System tray icon (`pystray`).** Cinnamon needs the AppIndicator extension enabled for
any tray icon (from any app, not just this one) to appear. If the Melodia tray icon
doesn't show up after installing `gir1.2-appindicator3-0.1`:
1. Open **Cinnamon Settings → Applets**
2. Find **"XApp Status Applet"** (or **"AppIndicator Support"** depending on your Mint
   version) and make sure it's enabled/added to your panel.

Neither of these required touching `main.py` — they're both optional features the script
already guards against failing gracefully (`HAS_KEYBOARD`, `HAS_TRAY` checks at the top),
so Melodia runs fine even if you skip both.

## Files in this folder

- `main.py` — your original script, untouched
- `requirements.txt` — pip dependencies
- `install.sh` — one-time system + Python setup
- `run.sh` — launches the app via the venv
- `install-launcher.sh` — adds Melodia to the Cinnamon app menu
- `melodia.desktop.template` — the menu entry template used by the above
- `melodia.png` — app icon for the menu entry
