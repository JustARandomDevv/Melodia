#!/usr/bin/env bash
# Installs a Melodia entry into the Cinnamon applications menu (per-user, no sudo needed).
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APPS_DIR="$HOME/.local/share/applications"
ICONS_DIR="$HOME/.local/share/icons"

mkdir -p "$APPS_DIR" "$ICONS_DIR"

cp "$DIR/melodia.png" "$ICONS_DIR/melodia.png"

sed "s|__INSTALL_DIR__|$DIR|g; s|Icon=$DIR/melodia.png|Icon=$ICONS_DIR/melodia.png|" \
    "$DIR/melodia.desktop.template" > "$APPS_DIR/melodia.desktop"

chmod +x "$DIR/run.sh"
chmod +x "$APPS_DIR/melodia.desktop"

# Refresh the menu cache so it shows up immediately
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$APPS_DIR" || true
fi

echo "Melodia installed. It should now appear in the Cinnamon menu (search 'Melodia')."
echo "You can also launch it any time with: $DIR/run.sh"
