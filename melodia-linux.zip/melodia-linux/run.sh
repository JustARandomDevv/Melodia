#!/usr/bin/env bash
# Launches Melodia using the venv created by install.sh.
# Does not alter main.py — just activates the environment and runs it.
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
source .venv/bin/activate
exec python3 main.py
