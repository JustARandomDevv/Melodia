import os
import random
import threading
import urllib.request
from io import BytesIO
import time
import asyncio
import json
import base64

import webview
from PIL import Image, ImageDraw
from ytmusicapi import YTMusic
import pygame
import yt_dlp
from mutagen.mp3 import MP3

try:
    import keyboard
    HAS_KEYBOARD = True
except ImportError:
    HAS_KEYBOARD = False

try:
    import pystray
    from pystray import MenuItem as item
    HAS_TRAY = True
except ImportError:
    HAS_TRAY = False

try:
    from pypresence import Presence
    HAS_DISCORD = True
except ImportError:
    HAS_DISCORD = False

DISCORD_APP_CLIENT_ID = "1508167962547458268"

# ─── HTML/CSS/JS UI ────────────────────────────────────────────────────────────
HTML = r"""

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Melodia</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --accent: #4cc38a;
    --accent2: #6b8cff;
    --accent-rgb: 76,195,138;
    --accent-glow: rgba(76,195,138,0.34);
    --text-primary: rgba(247,250,255,0.96);
    --text-secondary: rgba(247,250,255,0.68);
    --text-tertiary: rgba(247,250,255,0.36);
    --sidebar-w: 230px;
    --player-h: 100px;
    --radius: 22px;
    --radius-sm: 15px;
    --radius-xs: 10px;
    --font: 'Inter', -apple-system, BlinkMacSystemFont, 'Helvetica Neue', sans-serif;
    --spring: cubic-bezier(0.34,1.56,0.64,1);
    --ease: cubic-bezier(0.4,0,0.2,1);
    --lg-bg: rgba(255,255,255,0.07);
    --lg-border: rgba(255,255,255,0.15);
    --lg-border-hi: rgba(255,255,255,0.3);
    --lg-blur: blur(24px) saturate(200%);
    --lg-blur-sm: blur(18px) saturate(180%);
    --lg-shadow: 0 18px 40px rgba(0,0,0,0.30), inset 0 1.5px 0 rgba(255,255,255,0.16), inset 0 -1px 0 rgba(0,0,0,0.10);
    --lg-shadow-sm: 0 10px 25px rgba(0,0,0,0.24), inset 0 1px 0 rgba(255,255,255,0.12);
    --lg-specular: linear-gradient(135deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.04) 40%, transparent 70%);
    --app-bg: linear-gradient(140deg, #071018 0%, #10212a 45%, #080b12 100%);
    --bg-1: radial-gradient(140% 110% at 14% 8%, rgba(76,195,138,0.20) 0%, transparent 48%);
    --bg-2: radial-gradient(120% 100% at 84% 86%, rgba(94,125,255,0.15) 0%, transparent 52%);
    --bg-3: radial-gradient(105% 90% at 55% 52%, rgba(255,255,255,0.05) 0%, transparent 56%);
    --surface: rgba(255,255,255,0.085);
    --surface-soft: rgba(255,255,255,0.06);
    --surface-strong: rgba(255,255,255,0.125);
    --border-soft: rgba(255,255,255,0.16);
    --shadow-soft: 0 20px 46px rgba(0,0,0,0.28);
    --player-surface: rgba(5,10,16,0.72);
    --button-surface: rgba(255,255,255,0.08);
  }

  :root[data-theme="aurora"] {
    --accent: #7c8cff;
    --accent2: #4dc7ff;
    --accent-rgb: 124,140,255;
    --accent-glow: rgba(124,140,255,0.34);
    --app-bg: linear-gradient(135deg, #07111f 0%, #0f2238 45%, #080b14 100%);
    --bg-1: radial-gradient(140% 110% at 10% 8%, rgba(124,140,255,0.22) 0%, transparent 48%);
    --bg-2: radial-gradient(120% 100% at 83% 84%, rgba(77,199,255,0.16) 0%, transparent 50%);
    --bg-3: radial-gradient(95% 85% at 55% 52%, rgba(255,255,255,0.045) 0%, transparent 54%);
    --player-surface: rgba(6,16,28,0.74);
    --button-surface: rgba(124,140,255,0.12);
  }

  :root[data-theme="lavender"] {
    --accent: #ad87ff;
    --accent2: #7a7dff;
    --accent-rgb: 173,135,255;
    --accent-glow: rgba(173,135,255,0.34);
    --app-bg: linear-gradient(135deg, #120d1f 0%, #1d1730 45%, #08070f 100%);
    --bg-1: radial-gradient(140% 110% at 12% 6%, rgba(173,135,255,0.22) 0%, transparent 46%);
    --bg-2: radial-gradient(120% 100% at 82% 85%, rgba(122,125,255,0.16) 0%, transparent 50%);
    --bg-3: radial-gradient(95% 85% at 56% 50%, rgba(255,255,255,0.04) 0%, transparent 54%);
    --player-surface: rgba(24,14,38,0.76);
    --button-surface: rgba(173,135,255,0.14);
  }

  :root[data-theme="midnight"] {
    --accent: #67d6ff;
    --accent2: #7f8fff;
    --accent-rgb: 103,214,255;
    --accent-glow: rgba(103,214,255,0.34);
    --app-bg: linear-gradient(140deg, #04070c 0%, #0d1423 45%, #06080e 100%);
    --bg-1: radial-gradient(140% 110% at 12% 8%, rgba(103,214,255,0.16) 0%, transparent 46%);
    --bg-2: radial-gradient(120% 100% at 84% 84%, rgba(127,143,255,0.14) 0%, transparent 50%);
    --bg-3: radial-gradient(95% 86% at 55% 50%, rgba(255,255,255,0.035) 0%, transparent 52%);
    --player-surface: rgba(2,8,16,0.76);
    --button-surface: rgba(103,214,255,0.12);
  }

  :root[data-theme="sunset"] {
    --accent: #ff8f5c;
    --accent2: #ff5d7a;
    --accent-rgb: 255,143,92;
    --accent-glow: rgba(255,143,92,0.34);
    --app-bg: linear-gradient(140deg, #190d0b 0%, #2f1716 45%, #0d0807 100%);
    --bg-1: radial-gradient(140% 110% at 16% 8%, rgba(255,143,92,0.24) 0%, transparent 46%);
    --bg-2: radial-gradient(120% 100% at 84% 84%, rgba(255,93,122,0.16) 0%, transparent 50%);
    --bg-3: radial-gradient(100% 90% at 54% 50%, rgba(255,255,255,0.04) 0%, transparent 54%);
    --player-surface: rgba(28,10,10,0.76);
    --button-surface: rgba(255,143,92,0.14);
  }

  :root[data-theme="ocean"] {
    --accent: #2fb7ff;
    --accent2: #4ddcd5;
    --accent-rgb: 47,183,255;
    --accent-glow: rgba(47,183,255,0.34);
    --app-bg: linear-gradient(140deg, #07151f 0%, #0f2b3a 45%, #070b12 100%);
    --bg-1: radial-gradient(140% 110% at 14% 8%, rgba(47,183,255,0.22) 0%, transparent 46%);
    --bg-2: radial-gradient(120% 100% at 84% 84%, rgba(77,220,213,0.16) 0%, transparent 50%);
    --bg-3: radial-gradient(100% 90% at 56% 50%, rgba(255,255,255,0.04) 0%, transparent 54%);
    --player-surface: rgba(3,14,22,0.75);
    --button-surface: rgba(47,183,255,0.13);
  }

  :root[data-theme="rose"] {
    --accent: #ff6fa8;
    --accent2: #ff8ad6;
    --accent-rgb: 255,111,168;
    --accent-glow: rgba(255,111,168,0.34);
    --app-bg: linear-gradient(140deg, #180c16 0%, #2b1424 45%, #0a070a 100%);
    --bg-1: radial-gradient(140% 110% at 16% 8%, rgba(255,111,168,0.22) 0%, transparent 46%);
    --bg-2: radial-gradient(120% 100% at 84% 84%, rgba(255,138,214,0.16) 0%, transparent 50%);
    --bg-3: radial-gradient(100% 90% at 54% 50%, rgba(255,255,255,0.04) 0%, transparent 54%);
    --player-surface: rgba(28,10,20,0.76);
    --button-surface: rgba(255,111,168,0.13);
  }

  :root[data-theme="citrus"] {
    --accent: #ffcf4d;
    --accent2: #ff8c42;
    --accent-rgb: 255,207,77;
    --accent-glow: rgba(255,207,77,0.34);
    --app-bg: linear-gradient(140deg, #181106 0%, #2f2111 45%, #0c0905 100%);
    --bg-1: radial-gradient(140% 110% at 18% 8%, rgba(255,207,77,0.22) 0%, transparent 46%);
    --bg-2: radial-gradient(120% 100% at 82% 84%, rgba(255,140,66,0.16) 0%, transparent 50%);
    --bg-3: radial-gradient(100% 90% at 54% 50%, rgba(255,255,255,0.04) 0%, transparent 54%);
    --player-surface: rgba(28,16,6,0.76);
    --button-surface: rgba(255,207,77,0.13);
  }

  :root[data-theme="ice"] {
    --accent: #8fe3ff;
    --accent2: #6b89ff;
    --accent-rgb: 143,227,255;
    --accent-glow: rgba(143,227,255,0.34);
    --app-bg: linear-gradient(140deg, #08131b 0%, #102635 45%, #06090d 100%);
    --bg-1: radial-gradient(140% 110% at 16% 8%, rgba(143,227,255,0.22) 0%, transparent 46%);
    --bg-2: radial-gradient(120% 100% at 82% 84%, rgba(107,137,255,0.16) 0%, transparent 50%);
    --bg-3: radial-gradient(100% 90% at 54% 50%, rgba(255,255,255,0.04) 0%, transparent 54%);
    --player-surface: rgba(4,12,18,0.76);
    --button-surface: rgba(143,227,255,0.13);
  }

  html, body {
    height: 100%; width: 100%; overflow: hidden;
    font-family: var(--font);
    color: var(--text-primary);
    background: var(--app-bg);
    -webkit-font-smoothing: antialiased;
    transition: background 0.45s ease, color 0.45s ease;
  }

  /* ════════════════════════════════
     SVG LIQUID-GLASS FILTER DEFS
     (Squircle convex, SVG feTurbulence
      + feDisplacementMap approach)
  ════════════════════════════════ */
  #lg-filters { position:absolute; width:0; height:0; overflow:hidden; pointer-events:none; }

  /* ──────────────────────────────
     ANIMATED GRADIENT BACKGROUND
  ────────────────────────────── */
  #bg {
    position: fixed; inset: 0; z-index: 0;
    background:
      var(--bg-1),
      var(--bg-2),
      var(--bg-3),
      linear-gradient(140deg, #05080d 0%, #101b20 45%, #06070d 100%);
    animation: bgFlow 28s ease-in-out infinite;
  }
  #bg::before {
    content: '';
    position: absolute; inset: 0;
    background:
      radial-gradient(circle 700px at var(--mx,38%) var(--my,28%), rgba(48,209,88,0.13) 0%, transparent 42%),
      radial-gradient(circle 450px at 72% 62%, rgba(0,212,255,0.07) 0%, transparent 52%),
      radial-gradient(circle 320px at 28% 72%, rgba(255,0,110,0.045) 0%, transparent 48%);
    animation: bgOrbs 22s ease-in-out infinite;
    pointer-events: none;
  }
  @keyframes bgFlow {
    0%,100% { filter: hue-rotate(0deg) saturate(1.05); }
    50%      { filter: hue-rotate(14deg) saturate(1.18); }
  }
  @keyframes bgOrbs {
    0%,100% { opacity:.75; transform:scale(1); }
    50%     { opacity:1;   transform:scale(1.06); }
  }

  /* ════ APP SHELL ════ */
  #app {
    position: fixed; inset: 0; z-index: 1;
    display: grid;
    grid-template-columns: var(--sidebar-w) 1fr;
    grid-template-rows: 1fr var(--player-h);
    grid-template-areas: "sidebar main" "player player";
  }

  /* ── Scrollbar ── */
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.13); border-radius: 10px; }
  ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.22); }

  /* ════════════════════════════════
     LIQUID-GLASS BASE MIXIN (class)
  ════════════════════════════════ */
  .lg {
    background: var(--lg-bg);
    backdrop-filter: var(--lg-blur);
    -webkit-backdrop-filter: var(--lg-blur);
    border: 1px solid var(--lg-border);
    box-shadow: var(--lg-shadow);
    position: relative;
    overflow: hidden;
  }
  /* specular highlight overlay */
  .lg::before {
    content: '';
    position: absolute; inset: 0;
    background: var(--lg-specular);
    border-radius: inherit;
    pointer-events: none;
    z-index: 0;
  }
  /* rim-light highlight at top edge */
  .lg::after {
    content: '';
    position: absolute; top: 0; left: 8%; right: 8%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.35), transparent);
    border-radius: 50%;
    pointer-events: none;
    z-index: 0;
  }
  .lg > * { position: relative; z-index: 1; }

  .lg-sm {
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    box-shadow: var(--lg-shadow-sm);
  }

  /* ════════════════════════════════
     SIDEBAR
  ════════════════════════════════ */
  #sidebar {
    grid-area: sidebar;
    background: linear-gradient(180deg, rgba(255,255,255,0.058) 0%, rgba(255,255,255,0.028) 100%);
    backdrop-filter: var(--lg-blur);
    -webkit-backdrop-filter: var(--lg-blur);
    border-right: 1px solid var(--lg-border);
    display: flex; flex-direction: column;
    padding: 22px 0 18px;
    overflow: hidden;
    position: relative;
  }
  #sidebar::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.22), transparent);
    pointer-events: none;
  }
  /* subtle inset specular on sidebar */
  #sidebar::after {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(160deg, rgba(255,255,255,0.06) 0%, transparent 40%);
    pointer-events: none;
  }

  .logo {
    display: flex; align-items: center; gap: 11px;
    padding: 0 20px 26px;
    font-size: 22px; font-weight: 700; letter-spacing: -0.5px;
    position: relative; z-index: 1;
  }
  .logo-icon {
    width: 36px; height: 36px; border-radius: 10px;
    background: linear-gradient(135deg, var(--accent), #0b8f3c);
    display: flex; align-items: center; justify-content: center;
    font-size: 17px; flex-shrink: 0;
    box-shadow: 0 8px 28px rgba(48,209,88,0.55),
                inset 0 1.5px 0 rgba(255,255,255,0.32),
                inset 0 -1px 0 rgba(0,0,0,0.2);
    transition: transform 0.35s var(--spring), box-shadow 0.35s var(--ease);
  }
  .logo-icon:hover {
    transform: scale(1.1) rotate(-4deg);
    box-shadow: 0 14px 36px rgba(48,209,88,0.65);
  }

  .nav-section { padding: 0 10px; flex: 1; display: flex; flex-direction: column; gap: 3px; position: relative; z-index: 1; }

  .sidebar-footer {
    padding: 12px 14px 0; position: relative; z-index: 1;
  }
  .sidebar-label {
    font-size: 11px; letter-spacing: 0.22em; text-transform: uppercase;
    color: var(--text-tertiary); margin-bottom: 8px; padding: 0 4px;
  }
  .theme-switcher {
    display: flex; flex-wrap: wrap; gap: 8px;
  }
  .theme-select-wrap {
    position: relative;
  }
  .theme-select {
    appearance: none;
    -webkit-appearance: none;
    border: 1px solid var(--border-soft);
    background: var(--surface-soft);
    color: var(--text-primary);
    border-radius: 999px;
    padding: 8px 34px 8px 12px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    outline: none;
    transition: all 0.24s var(--ease);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.12);
  }
  .theme-chip {
    border: 1px solid rgba(255,255,255,0.14);
    background: linear-gradient(145deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%);
    color: var(--text-primary);
    padding: 10px 14px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.24s var(--ease);
    user-select: none;
  }
  .theme-chip:hover,
  .theme-chip.active {
    background: linear-gradient(145deg, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.06) 100%);
    border-color: rgba(76,195,138,0.45);
    color: var(--text-primary);
  }
  .theme-select:hover,
  .theme-select:focus {
    border-color: var(--accent);
    background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.06) 100%);
    box-shadow: 0 8px 18px rgba(0,0,0,0.22);
  }
  .theme-select option {
    color: #111;
  }
  .theme-select-wrap::after {
    content: '▾';
    position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
    color: var(--text-secondary); pointer-events: none; font-size: 11px;
  }
  .theme-switcher.inline { justify-content: flex-end; }

  .nav-btn {
    display: flex; align-items: center; gap: 11px;
    padding: 10px 13px;
    border-radius: var(--radius-sm);
    cursor: pointer;
    font-size: 13.5px; font-weight: 500;
    color: var(--text-secondary);
    transition: all 0.28s var(--ease);
    user-select: none;
    border: 1px solid transparent;
    position: relative; overflow: hidden;
  }
  /* hover refraction shimmer */
  .nav-btn::before {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(110deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.03) 55%, transparent 100%);
    opacity: 0; transition: opacity 0.28s var(--ease);
    border-radius: inherit;
  }
  .nav-btn:hover { color: var(--text-primary); background: rgba(255,255,255,0.065); }
  .nav-btn:hover::before { opacity: 1; }
  .nav-btn.active {
    color: var(--text-primary);
    background: linear-gradient(135deg, rgba(48,209,88,0.18) 0%, rgba(48,209,88,0.08) 100%);
    border-color: rgba(48,209,88,0.32);
    box-shadow: 0 6px 20px rgba(48,209,88,0.18),
                inset 0 1px 0 rgba(255,255,255,0.14),
                inset 0 -1px 0 rgba(0,0,0,0.08);
  }
  .nav-btn.active .nav-icon { color: var(--accent); filter: drop-shadow(0 0 6px var(--accent-glow)); }
  .nav-icon { font-size: 16px; flex-shrink: 0; width: 20px; text-align: center; }

  /* ════════════════════════════════
     MAIN CONTENT AREA
  ════════════════════════════════ */
  #main { grid-area: main; overflow: hidden; position: relative; }
  .frame { display: none; height: 100%; overflow-y: auto; padding: 30px 30px 22px; }
  .frame.active { display: block; }
  .page-title {
    font-size: 32px; font-weight: 700; letter-spacing: -1px;
    margin-bottom: 26px;
    background: linear-gradient(135deg, var(--text-primary), rgba(255,255,255,0.65));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  }

  /* ════════════════════════════════
     LIQUID-GLASS CARD
     (physics-inspired squircle bezel)
  ════════════════════════════════ */
  .glass-card {
    background: linear-gradient(145deg, rgba(255,255,255,0.09) 0%, rgba(255,255,255,0.035) 100%);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    border: 1px solid var(--lg-border);
    border-radius: var(--radius);
    box-shadow:
      0 8px 36px rgba(0,0,0,0.48),
      0 1px  0   rgba(255,255,255,0.18) inset,
      0 -1px 0   rgba(0,0,0,0.12) inset;
    transition: transform 0.38s var(--spring), box-shadow 0.38s var(--ease), border-color 0.28s var(--ease);
    position: relative; overflow: hidden;
  }
  /* Squircle specular – top-left dome highlight */
  .glass-card::before {
    content: '';
    position: absolute;
    top: -30%; left: -20%;
    width: 80%; height: 70%;
    background: radial-gradient(ellipse at 35% 38%, rgba(255,255,255,0.18) 0%, transparent 65%);
    pointer-events: none; border-radius: 50%;
  }
  /* rim light */
  .glass-card::after {
    content: '';
    position: absolute; top: 0; left: 10%; right: 10%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.38), transparent);
    pointer-events: none;
  }
  .glass-card:hover {
    transform: translateY(-5px) scale(1.018);
    border-color: rgba(48,209,88,0.38);
    box-shadow:
      0 22px 52px rgba(48,209,88,0.22),
      0 14px 44px rgba(0,0,0,0.55),
      0 1px  0   rgba(255,255,255,0.24) inset;
  }

  .settings-section {
    border-radius: var(--radius);
    padding: 18px 20px;
    background: linear-gradient(145deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.035) 100%);
    border: 1px solid var(--lg-border);
    box-shadow: var(--lg-shadow-sm);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
  }

  /* ════════════════════════════════
     DISCOVER GRID
  ════════════════════════════════ */
  #grid-discover {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
    gap: 18px;
  }
  .disc-card {
    padding: 14px 14px 13px;
    cursor: pointer;
    border-radius: var(--radius);
    background: linear-gradient(148deg, rgba(255,255,255,0.085) 0%, rgba(255,255,255,0.032) 100%);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    border: 1px solid var(--lg-border);
    box-shadow: 0 6px 24px rgba(0,0,0,0.42), inset 0 1px 0 rgba(255,255,255,0.16);
    transition: transform 0.38s var(--spring), box-shadow 0.38s var(--ease), border-color 0.28s var(--ease);
    position: relative; overflow: hidden;
  }
  /* specular dome */
  .disc-card::before {
    content: '';
    position: absolute; top: -25%; left: -15%; width: 75%; height: 60%;
    background: radial-gradient(ellipse at 40% 40%, rgba(255,255,255,0.16) 0%, transparent 70%);
    border-radius: 50%; pointer-events: none;
    transition: opacity 0.3s var(--ease);
  }
  /* rim line */
  .disc-card::after {
    content: '';
    position: absolute; top: 0; left: 12%; right: 12%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.32), transparent);
    pointer-events: none;
  }
  .disc-card:hover {
    transform: translateY(-7px) scale(1.035);
    border-color: rgba(48,209,88,0.38);
    box-shadow:
      0 28px 60px rgba(48,209,88,0.18),
      0 18px 50px rgba(0,0,0,0.58),
      inset 0 1.5px 0 rgba(255,255,255,0.24);
  }
  .disc-art {
    width: 100%; aspect-ratio: 1;
    border-radius: 12px;
    background: rgba(255,255,255,0.07);
    object-fit: cover; display: block;
    font-size: 36px; text-align: center; line-height: 140px;
    margin-bottom: 12px; overflow: hidden;
    box-shadow: 0 4px 18px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.1);
  }
  .disc-art img { width: 100%; height: 100%; object-fit: cover; border-radius: 12px; display: block; }
  .disc-title { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .disc-artist { font-size: 11.5px; color: var(--text-secondary); margin-top: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

  /* ════════════════════════════════
     SEARCH
  ════════════════════════════════ */
  .search-bar-wrap { position: relative; margin-bottom: 22px; }
  .search-bar {
    width: 100%; height: 50px;
    background: linear-gradient(135deg, rgba(255,255,255,0.085) 0%, rgba(255,255,255,0.04) 100%);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    border: 1px solid var(--lg-border);
    border-radius: 50px;
    color: var(--text-primary);
    font-size: 14.5px; font-family: var(--font);
    padding: 0 22px 0 50px;
    outline: none;
    transition: all 0.28s var(--ease);
    box-shadow: 0 4px 18px rgba(0,0,0,0.32), inset 0 1px 0 rgba(255,255,255,0.14);
    position: relative;
  }
  .search-bar::placeholder { color: var(--text-tertiary); }
  .search-bar:focus {
    border-color: var(--accent);
    background: linear-gradient(135deg, rgba(48,209,88,0.13) 0%, rgba(48,209,88,0.06) 100%);
    box-shadow: 0 0 0 3px rgba(48,209,88,0.32), 0 8px 32px rgba(48,209,88,0.18), inset 0 1px 0 rgba(255,255,255,0.18);
  }
  .search-icon { position: absolute; left: 18px; top: 50%; transform: translateY(-50%); color: var(--text-secondary); font-size: 16px; pointer-events: none; }

  .search-row {
    display: flex; align-items: center; gap: 13px;
    padding: 11px 16px;
    border-radius: var(--radius-sm);
    margin-bottom: 7px;
    background: linear-gradient(135deg, rgba(255,255,255,0.055) 0%, rgba(255,255,255,0.022) 100%);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    border: 1px solid var(--lg-border);
    transition: all 0.28s var(--ease);
    cursor: pointer;
    position: relative; overflow: hidden;
  }
  .search-row::before {
    content: '';
    position: absolute; top: 0; left: 10%; right: 10%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.22), transparent);
    pointer-events: none;
  }
  .search-row::after {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(135deg, rgba(48,209,88,0.1) 0%, transparent 55%);
    opacity: 0; transition: opacity 0.28s; border-radius: inherit;
  }
  .search-row:hover {
    background: linear-gradient(135deg, rgba(255,255,255,0.095) 0%, rgba(255,255,255,0.042) 100%);
    border-color: rgba(48,209,88,0.28);
    box-shadow: 0 8px 26px rgba(48,209,88,0.13);
    transform: translateX(3px);
  }
  .search-row:hover::after { opacity: 1; }
  .search-thumb {
    width: 46px; height: 46px; border-radius: var(--radius-xs);
    background: rgba(255,255,255,0.09); object-fit: cover; flex-shrink: 0;
    font-size: 18px; display: flex; align-items: center; justify-content: center;
    overflow: hidden; box-shadow: 0 3px 12px rgba(0,0,0,0.35);
    position: relative; z-index: 1;
  }
  .search-thumb img { width: 100%; height: 100%; object-fit: cover; }
  .search-info { flex: 1; min-width: 0; position: relative; z-index: 1; }
  .search-title { font-size: 13.5px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .search-meta { font-size: 11.5px; color: var(--text-secondary); margin-top: 2px; }

  /* ════════════════════════════════
     LIBRARY
  ════════════════════════════════ */
  #grid-library { display: grid; grid-template-columns: repeat(auto-fill, minmax(175px, 1fr)); gap: 18px; }
  .lib-card {
    padding: 14px 14px 13px;
    border-radius: var(--radius);
    background: linear-gradient(148deg, rgba(255,255,255,0.075) 0%, rgba(255,255,255,0.028) 100%);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    border: 1px solid var(--lg-border);
    box-shadow: var(--lg-shadow-sm);
    transition: all 0.32s var(--spring);
    position: relative; overflow: hidden;
  }
  .lib-card::before {
    content: '';
    position: absolute; top: -28%; left: -18%; width: 72%; height: 62%;
    background: radial-gradient(ellipse at 38% 38%, rgba(255,255,255,0.14) 0%, transparent 68%);
    border-radius: 50%; pointer-events: none;
  }
  .lib-card::after {
    content: '';
    position: absolute; top: 0; left: 12%; right: 12%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.28), transparent);
    pointer-events: none;
  }
  .lib-card:hover {
    transform: translateY(-4px);
    border-color: rgba(255,255,255,0.24);
    box-shadow: 0 16px 40px rgba(0,0,0,0.55), inset 0 1.5px 0 rgba(255,255,255,0.22);
  }
  .lib-art {
    width: 100%; aspect-ratio: 1; border-radius: 12px;
    background: rgba(255,255,255,0.07);
    display: flex; align-items: center; justify-content: center;
    font-size: 32px; margin-bottom: 12px; overflow: hidden;
    box-shadow: 0 4px 18px rgba(0,0,0,0.42);
    position: relative; z-index: 1;
  }
  .lib-art img { width: 100%; height: 100%; object-fit: cover; border-radius: 12px; }
  .lib-title { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; position: relative; z-index: 1; }
  .lib-artist { font-size: 11.5px; color: var(--text-secondary); margin-top: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; position: relative; z-index: 1; }
  .lib-actions { display: flex; gap: 5px; margin-top: 10px; position: relative; z-index: 1; }
  .lib-btn {
    flex: 1; height: 31px; border-radius: 50px;
    border: 1px solid rgba(255,255,255,0.13);
    background: linear-gradient(135deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0.025) 100%);
    color: var(--text-secondary);
    cursor: pointer; font-size: 13px; transition: all 0.28s var(--ease);
    display: flex; align-items: center; justify-content: center;
    user-select: none;
    position: relative; overflow: hidden;
  }
  .lib-btn::before {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.13) 0%, transparent 60%);
    opacity: 0; transition: opacity 0.2s; border-radius: inherit;
  }
  .lib-btn:hover { color: var(--text-primary); border-color: rgba(255,255,255,0.22); transform: translateY(-1px); }
  .lib-btn:hover::before { opacity: 1; }
  .lib-btn.green { background: linear-gradient(135deg, rgba(48,209,88,0.26) 0%, rgba(48,209,88,0.12) 100%); border-color: rgba(48,209,88,0.5); color: var(--accent); }
  .lib-btn.green:hover { background: linear-gradient(135deg, var(--accent), #0a8f3a); color: #000; border-color: var(--accent); box-shadow: 0 5px 16px rgba(48,209,88,0.35); }
  .lib-btn.fav-active { color: #ff4f4f; border-color: rgba(255,79,79,0.5); }
  .lib-btn.red { background: linear-gradient(135deg, rgba(255,60,60,0.18) 0%, rgba(255,60,60,0.08) 100%); border-color: rgba(255,60,60,0.4); color: #ff7070; }
  .lib-btn.red:hover { background: linear-gradient(135deg, rgba(255,60,60,0.34) 0%, rgba(255,60,60,0.15) 100%); border-color: rgba(255,60,60,0.6); box-shadow: 0 4px 14px rgba(255,60,60,0.22); }
  .lib-btn.blue { background: linear-gradient(135deg, rgba(160,120,255,0.24) 0%, rgba(160,120,255,0.1) 100%); border-color: rgba(160,120,255,0.45); color: #b898ff; }
  .lib-btn.blue:hover { background: linear-gradient(135deg, rgba(160,120,255,0.42) 0%, rgba(160,120,255,0.2) 100%); border-color: rgba(160,120,255,0.75); box-shadow: 0 4px 14px rgba(160,120,255,0.3); }

  /* ════════════════════════════════
     PLAYLISTS
  ════════════════════════════════ */
  .pl-row {
    display: flex; align-items: center; gap: 16px;
    padding: 15px 18px;
    border-radius: var(--radius-sm);
    margin-bottom: 9px;
    background: linear-gradient(135deg, rgba(255,255,255,0.058) 0%, rgba(255,255,255,0.022) 100%);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    border: 1px solid var(--lg-border);
    box-shadow: 0 4px 14px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.12);
    transition: all 0.32s var(--spring);
    cursor: pointer; position: relative; overflow: hidden;
  }
  .pl-row::before {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(135deg, rgba(48,209,88,0.1) 0%, transparent 55%);
    opacity: 0; transition: opacity 0.28s; border-radius: inherit;
  }
  .pl-row::after {
    content: '';
    position: absolute; top: 0; left: 8%; right: 8%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.24), transparent);
    pointer-events: none;
  }
  .pl-row:hover { transform: translateY(-3px) translateX(2px); border-color: rgba(48,209,88,0.3); box-shadow: 0 12px 30px rgba(48,209,88,0.14); }
  .pl-row:hover::before { opacity: 1; }
  .pl-art {
    width: 58px; height: 58px; border-radius: var(--radius-xs);
    background: linear-gradient(135deg, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0.05) 100%);
    display: flex; align-items: center; justify-content: center;
    font-size: 23px; flex-shrink: 0; overflow: hidden;
    box-shadow: 0 4px 14px rgba(0,0,0,0.38), inset 0 1px 0 rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.1);
    position: relative; z-index: 1;
  }
  .pl-info { flex: 1; min-width: 0; position: relative; z-index: 1; }
  .pl-name { font-size: 15px; font-weight: 600; }
  .pl-meta { font-size: 12px; color: var(--text-secondary); margin-top: 3px; }
  .pl-btns { display: flex; gap: 8px; z-index: 2; }

  /* ════════════════════════════════
     QUEUE
  ════════════════════════════════ */
  .q-row {
    display: flex; align-items: center; gap: 14px;
    padding: 11px 15px;
    border-radius: var(--radius-sm);
    margin-bottom: 6px;
    background: linear-gradient(135deg, rgba(255,255,255,0.052) 0%, rgba(255,255,255,0.018) 100%);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    border: 1px solid var(--lg-border);
    transition: all 0.28s var(--ease);
    cursor: pointer; position: relative; overflow: hidden;
  }
  .q-row::before {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(135deg, rgba(48,209,88,0.1) 0%, transparent 55%);
    opacity: 0; transition: opacity 0.28s; border-radius: inherit;
  }
  .q-row:hover { background: linear-gradient(135deg, rgba(255,255,255,0.085) 0%, rgba(255,255,255,0.038) 100%); border-color: rgba(48,209,88,0.28); }
  .q-row:hover::before { opacity: 1; }
  .q-row.current-track {
    background: linear-gradient(135deg, rgba(48,209,88,0.16) 0%, rgba(48,209,88,0.07) 100%);
    border-color: rgba(48,209,88,0.32);
    box-shadow: 0 4px 18px rgba(48,209,88,0.18), inset 0 1px 0 rgba(255,255,255,0.14);
  }
  .q-num { font-size: 12px; color: var(--text-tertiary); width: 24px; text-align: center; flex-shrink: 0; position: relative; z-index: 1; }
  .q-num.playing { color: var(--accent); font-size: 15px; filter: drop-shadow(0 0 5px var(--accent-glow)); }
  .q-art { width: 40px; height: 40px; border-radius: 7px; background: rgba(255,255,255,0.07); display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0; overflow: hidden; position: relative; z-index: 1; }
  .q-art img { width: 100%; height: 100%; object-fit: cover; }
  .q-info { flex: 1; min-width: 0; position: relative; z-index: 1; }
  .q-title { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .q-artist { font-size: 11.5px; color: var(--text-secondary); }

  /* ════════════════════════════════
     LYRICS
  ════════════════════════════════ */
  #lyrics-content {
    font-size: 17px; line-height: 2.1;
    color: var(--text-secondary);
    white-space: pre-wrap; word-break: break-word;
    padding: 8px 0 40px;
    font-weight: 400;
  }

  /* ════════════════════════════════
     SETTINGS
  ════════════════════════════════ */
  .settings-section {
    background: linear-gradient(148deg, rgba(255,255,255,0.065) 0%, rgba(255,255,255,0.022) 100%);
    backdrop-filter: var(--lg-blur-sm);
    -webkit-backdrop-filter: var(--lg-blur-sm);
    border: 1px solid var(--lg-border);
    border-radius: var(--radius);
    padding: 22px 24px;
    margin-bottom: 18px;
    box-shadow: var(--lg-shadow-sm);
    transition: all 0.28s var(--ease);
    position: relative; overflow: hidden;
  }
  .settings-section::before {
    content: '';
    position: absolute; top: 0; left: 8%; right: 8%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.26), transparent);
    pointer-events: none;
  }
  .settings-section:hover { border-color: rgba(48,209,88,0.22); box-shadow: 0 8px 28px rgba(0,0,0,0.35); }
  .settings-title { font-size: 12.5px; font-weight: 600; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 15px; }
  .settings-row { display: flex; align-items: center; justify-content: space-between; padding: 13px 0; border-bottom: 1px solid rgba(255,255,255,0.06); }
  .settings-row:last-child { border-bottom: none; padding-bottom: 0; }
  .settings-label { font-size: 14.5px; font-weight: 500; }
  .settings-sublabel { font-size: 12px; color: var(--text-secondary); margin-top: 3px; }

  /* iOS-style toggle – liquid glass thumb */
  .toggle-wrap { position: relative; width: 52px; height: 30px; flex-shrink: 0; }
  .toggle-wrap input { opacity: 0; width: 0; height: 0; position: absolute; }
  .toggle-slider {
    position: absolute; cursor: pointer; inset: 0;
    border-radius: 50px;
    background: rgba(255,255,255,0.16);
    border: 1px solid rgba(255,255,255,0.2);
    transition: all 0.35s var(--ease);
    box-shadow: inset 0 1px 0 rgba(0,0,0,0.1), inset 0 -1px 0 rgba(255,255,255,0.06);
  }
  .toggle-slider::before {
    content: '';
    position: absolute; height: 24px; width: 24px; left: 2px; bottom: 2px;
    background: linear-gradient(145deg, rgba(255,255,255,0.98), rgba(235,235,235,0.95));
    border-radius: 50%;
    transition: all 0.35s var(--spring);
    box-shadow:
      0 3px 10px rgba(0,0,0,0.25),
      inset 0 1.5px 0 rgba(255,255,255,0.8),
      inset 0 -1px 0 rgba(0,0,0,0.08);
  }
  input:checked + .toggle-slider {
    background: linear-gradient(135deg, var(--accent), #0a8f3a);
    border-color: var(--accent);
    box-shadow: 0 0 16px rgba(48,209,88,0.35), inset 0 1px 0 rgba(255,255,255,0.18);
  }
  input:checked + .toggle-slider::before { transform: translateX(22px); }

  /* ════════════════════════════════
     PLAYER BAR  — full liquid glass
  ════════════════════════════════ */
  #player {
    grid-area: player;
    background: linear-gradient(180deg, rgba(8,10,15,0.72) 0%, rgba(8,10,15,0.92) 100%);
    backdrop-filter: blur(48px) saturate(220%);
    -webkit-backdrop-filter: blur(48px) saturate(220%);
    border-top: 1px solid rgba(255,255,255,0.11);
    display: grid;
    grid-template-columns: minmax(220px, 290px) minmax(240px, 1fr) minmax(180px, 290px);
    align-items: center;
    padding: 0 24px;
    gap: 16px;
    position: relative; z-index: 10;
    box-shadow:
      0 -10px 40px rgba(0,0,0,0.35),
      inset 0 1px 0 rgba(255,255,255,0.08);
  }
  @media (max-width: 900px) {
    #app {
      grid-template-columns: 1fr;
      grid-template-rows: 1fr auto;
    }
    #player {
      grid-template-columns: 1fr;
      padding: 16px;
      row-gap: 14px;
    }
    .player-info,
    .player-center,
    .player-right {
      justify-content: center;
      width: 100%;
    }
    .player-center { align-items: center; }
    .player-right { justify-content: center; }
    .timeline { width: 100%; }
    .player-info { order: 1; }
    .player-center { order: 2; }
    .player-right { order: 3; }
  }
  /* top rim specular */
  #player::before {
    content: '';
    position: absolute; top: 0; left: 5%; right: 5%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.22), transparent);
    pointer-events: none;
  }
  /* ambient glow */
  #player::after {
    content: '';
    position: absolute; inset: 0; pointer-events: none;
    background: radial-gradient(ellipse 80% 120% at 50% 100%, rgba(48,209,88,0.07) 0%, transparent 65%);
    animation: playerPulse 5s ease-in-out infinite;
  }
  @keyframes playerPulse { 0%,100%{opacity:.7} 50%{opacity:1} }

  #player-art {
    width: 60px; height: 60px; border-radius: 11px;
    background: linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,255,255,0.04));
    display: flex; align-items: center; justify-content: center;
    font-size: 24px; flex-shrink: 0; overflow: hidden;
    box-shadow:
      0 8px 28px rgba(0,0,0,0.55),
      inset 0 1.5px 0 rgba(255,255,255,0.18),
      inset 0 -1px 0 rgba(0,0,0,0.12);
    transition: transform 0.35s var(--spring), box-shadow 0.3s var(--ease);
    border: 1px solid rgba(255,255,255,0.12);
    position: relative;
  }
  #player-art::after {
    content: '';
    position: absolute; top: 0; left: 10%; right: 10%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.36), transparent);
    pointer-events: none;
  }
  #player-art:hover { transform: scale(1.06); box-shadow: 0 12px 36px rgba(48,209,88,0.22); }

  #btn-play-pause {
    width: 46px; height: 46px;
    background: linear-gradient(135deg, var(--accent), #0a8f3a);
    color: #000;
    border: none; border-radius: 50%;
    cursor: pointer; font-size: 17px;
    display: flex; align-items: center; justify-content: center;
    transition: transform 0.35s var(--spring), box-shadow 0.3s var(--ease);
    box-shadow:
      0 8px 28px rgba(48,209,88,0.45),
      inset 0 1.5px 0 rgba(255,255,255,0.28),
      inset 0 -1px 0 rgba(0,0,0,0.15);
    position: relative; overflow: hidden;
  }
  #btn-play-pause::before {
    content: '';
    position: absolute; inset: 0;
    background: radial-gradient(circle at 35% 32%, rgba(255,255,255,0.28) 0%, transparent 60%);
    border-radius: inherit; pointer-events: none;
  }
  #btn-play-pause:hover { transform: scale(1.12); box-shadow: 0 14px 36px rgba(48,209,88,0.58); }
  #btn-play-pause:active { transform: scale(0.96); }

  .timeline { display: flex; align-items: center; gap: 8px; width: 100%; }
  .time-label { font-size: 11px; color: var(--text-tertiary); flex-shrink: 0; min-width: 32px; font-variant-numeric: tabular-nums; }
  .time-label.right { text-align: right; }

  /* ── Liquid glass progress bar ── */
  .progress-wrap {
    flex: 1; height: 4px; position: relative; cursor: pointer;
    border-radius: 4px;
    background: rgba(255,255,255,0.12);
    box-shadow: inset 0 1px 2px rgba(0,0,0,0.25), inset 0 -1px 0 rgba(255,255,255,0.05);
    transition: height 0.22s var(--ease);
  }
  .progress-wrap:hover { height: 7px; }
  .progress-fill {
    height: 100%; border-radius: 4px;
    background: linear-gradient(90deg, rgba(48,209,88,0.85), var(--accent));
    transition: width 0.18s linear;
    position: relative;
    box-shadow: 0 0 14px rgba(48,209,88,0.45);
  }
  .progress-fill::after {
    content: '';
    position: absolute; right: -6px; top: 50%; transform: translateY(-50%);
    width: 14px; height: 14px; border-radius: 50%;
    background: white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.38), inset 0 1px 0 rgba(255,255,255,0.8);
    opacity: 0; transition: opacity 0.15s;
  }
  .progress-wrap:hover .progress-fill::after { opacity: 1; }

  .player-info { display: flex; align-items: center; gap: 13px; min-width: 0; position: relative; z-index: 1; }
  #player-title { font-size: 14px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  #player-artist { font-size: 12px; color: var(--text-secondary); margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  #player-fav { font-size: 19px; cursor: pointer; padding: 4px; color: var(--text-tertiary); transition: all 0.3s var(--spring); flex-shrink: 0; }
  #player-fav.active { color: #ff4f4f; filter: drop-shadow(0 0 6px rgba(255,79,79,0.5)); }
  #player-fav:hover { transform: scale(1.18); }

  .player-center { display: flex; flex-direction: column; align-items: center; gap: 9px; position: relative; z-index: 1; }
  .player-controls { display: flex; align-items: center; gap: 16px; }
  .ctrl-btn {
    background: linear-gradient(145deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0.025) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    color: var(--text-secondary);
    cursor: pointer; font-size: 20px;
    transition: all 0.3s var(--spring);
    padding: 9px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 3px 10px rgba(0,0,0,0.22), inset 0 1px 0 rgba(255,255,255,0.1);
    min-width: 40px; min-height: 40px;
    position: relative; overflow: hidden;
  }
  .ctrl-btn::before {
    content: '';
    position: absolute; inset: 0;
    background: radial-gradient(circle at 35% 32%, rgba(255,255,255,0.16) 0%, transparent 65%);
    border-radius: inherit; pointer-events: none;
  }
  .ctrl-btn:hover {
    color: var(--text-primary);
    transform: scale(1.14);
    background: linear-gradient(145deg, rgba(255,255,255,0.13) 0%, rgba(255,255,255,0.06) 100%);
    border-color: rgba(48,209,88,0.32);
    box-shadow: 0 6px 20px rgba(48,209,88,0.16);
  }
  .ctrl-btn:active { transform: scale(0.93); }

  .player-right { display: flex; align-items: center; justify-content: flex-end; gap: 12px; position: relative; z-index: 1; }
  .vol-icon { color: var(--text-secondary); font-size: 16px; flex-shrink: 0; }
  .vol-wrap {
    width: 96px; height: 4px; position: relative; cursor: pointer;
    border-radius: 4px;
    background: rgba(255,255,255,0.12);
    box-shadow: inset 0 1px 2px rgba(0,0,0,0.2);
    flex-shrink: 0;
    transition: height 0.2s var(--ease);
  }
  .vol-wrap:hover { height: 7px; }
  .vol-fill { height: 100%; border-radius: 4px; background: linear-gradient(90deg, rgba(48,209,88,0.7), rgba(48,209,88,0.9)); box-shadow: 0 0 10px rgba(48,209,88,0.32); pointer-events: none; }

  /* ════════════════════════════════
     BUTTONS
  ════════════════════════════════ */
  .btn {
    display: inline-flex; align-items: center; justify-content: center; gap: 6px;
    padding: 9px 18px; border-radius: 50px;
    font-size: 13px; font-weight: 600; font-family: var(--font);
    cursor: pointer; border: 1px solid transparent;
    transition: all 0.3s var(--spring); user-select: none;
    position: relative; overflow: hidden;
  }
  .btn::before {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(145deg, rgba(255,255,255,0.18) 0%, transparent 55%);
    border-radius: inherit; pointer-events: none;
  }
  .btn-green {
    background: linear-gradient(135deg, var(--accent), #0a8f3a);
    color: #000;
    box-shadow: 0 8px 26px rgba(48,209,88,0.42), inset 0 1.5px 0 rgba(255,255,255,0.28);
    border: 1px solid rgba(255,255,255,0.15);
  }
  .btn-green:hover { transform: translateY(-2px) scale(1.04); box-shadow: 0 14px 34px rgba(48,209,88,0.54); background: linear-gradient(135deg, #40e86a, #0cb844); }
  .btn-glass {
    background: linear-gradient(145deg, rgba(255,255,255,0.09) 0%, rgba(255,255,255,0.035) 100%);
    backdrop-filter: var(--lg-blur-sm); -webkit-backdrop-filter: var(--lg-blur-sm);
    border-color: var(--lg-border); color: var(--text-primary);
    box-shadow: 0 4px 18px rgba(0,0,0,0.32), inset 0 1px 0 rgba(255,255,255,0.16);
  }
  .btn-glass:hover { transform: translateY(-2px); border-color: rgba(48,209,88,0.3); box-shadow: 0 8px 26px rgba(48,209,88,0.14); }
  .btn-danger {
    background: linear-gradient(135deg, rgba(255,55,55,0.22) 0%, rgba(255,55,55,0.1) 100%);
    border-color: rgba(255,55,55,0.42); color: #ff7070;
    box-shadow: 0 4px 14px rgba(255,55,55,0.12);
  }
  .btn-danger:hover { transform: translateY(-2px); background: linear-gradient(135deg, rgba(255,55,55,0.34) 0%, rgba(255,55,55,0.16) 100%); box-shadow: 0 8px 22px rgba(255,55,55,0.22); }

  /* ════════════════════════════════
     MODAL
  ════════════════════════════════ */
  .modal-backdrop {
    position: fixed; inset: 0; z-index: 100;
    background: rgba(0,0,0,0.65);
    backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
    display: flex; align-items: center; justify-content: center;
    opacity: 0; pointer-events: none; transition: opacity 0.28s var(--ease);
  }
  .modal-backdrop.show { opacity: 1; pointer-events: all; }
  .modal {
    background: linear-gradient(148deg, rgba(18,22,32,0.96) 0%, rgba(12,18,26,0.96) 100%);
    backdrop-filter: blur(48px) saturate(220%); -webkit-backdrop-filter: blur(48px) saturate(220%);
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 24px; padding: 30px;
    width: 470px; max-width: 95vw; max-height: 80vh;
    box-shadow:
      0 32px 88px rgba(0,0,0,0.82),
      0 0 48px rgba(48,209,88,0.09),
      inset 0 1.5px 0 rgba(255,255,255,0.16);
    transform: scale(0.94); transition: transform 0.3s var(--spring);
    display: flex; flex-direction: column;
    position: relative; overflow: hidden;
  }
  .modal::before {
    content: '';
    position: absolute; top: -30%; left: -20%; width: 70%; height: 60%;
    background: radial-gradient(ellipse at 40% 40%, rgba(255,255,255,0.09) 0%, transparent 70%);
    border-radius: 50%; pointer-events: none;
  }
  .modal::after {
    content: '';
    position: absolute; top: 0; left: 10%; right: 10%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.32), transparent);
    pointer-events: none;
  }
  .modal-backdrop.show .modal { transform: scale(1); }
  .modal-title { font-size: 20px; font-weight: 700; margin-bottom: 22px; position: relative; z-index: 1; }
  .modal-input {
    width: 100%; height: 46px;
    background: linear-gradient(135deg, rgba(255,255,255,0.09) 0%, rgba(255,255,255,0.04) 100%);
    border: 1px solid var(--lg-border);
    border-radius: var(--radius-sm);
    color: var(--text-primary); font-size: 14px; font-family: var(--font);
    padding: 0 15px; outline: none; margin-bottom: 18px;
    transition: all 0.28s var(--ease);
    backdrop-filter: blur(12px);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.1);
    position: relative; z-index: 1;
  }
  .modal-input:focus { border-color: var(--accent); background: linear-gradient(135deg, rgba(48,209,88,0.15) 0%, rgba(48,209,88,0.07) 100%); box-shadow: 0 0 0 3px rgba(48,209,88,0.28), inset 0 1px 0 rgba(255,255,255,0.15); }
  .modal-body { flex: 1; overflow-y: auto; margin-bottom: 18px; position: relative; z-index: 1; }
  .modal-check { display: flex; align-items: center; gap: 10px; padding: 9px 10px; border-radius: var(--radius-xs); cursor: pointer; transition: background 0.15s; font-size: 13px; color: var(--text-secondary); }
  .modal-check:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }
  .modal-check input { accent-color: var(--accent); width: 16px; height: 16px; flex-shrink: 0; }

  /* ════════════════════════════════
     LOADING & UTILITIES
  ════════════════════════════════ */
  .spinner {
    width: 36px; height: 36px; margin: 44px auto;
    border: 3px solid rgba(255,255,255,0.1);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.75s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .load-bar {
    height: 2px; border-radius: 2px;
    background: linear-gradient(90deg, transparent, var(--accent), transparent);
    background-size: 200% 100%;
    animation: shimmer 1.1s infinite;
    margin: 6px 0 22px;
  }
  @keyframes shimmer { from { background-position: -200% 0; } to { background-position: 200% 0; } }

  .top-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 26px; }
  .empty-state { text-align: center; padding: 64px 20px; color: var(--text-secondary); }
  .empty-state h3 { font-size: 17px; font-weight: 600; color: var(--text-primary); margin-bottom: 8px; }
  .empty-state p { font-size: 13.5px; }

  /* ── Toast ── */
  #toast {
    position: fixed; bottom: calc(var(--player-h) + 16px); left: 50%; transform: translateX(-50%) translateY(14px);
    background: linear-gradient(145deg, rgba(18,22,32,0.94), rgba(12,18,26,0.94));
    backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 50px; padding: 10px 22px;
    font-size: 13px; font-weight: 500;
    z-index: 200; opacity: 0; pointer-events: none;
    transition: all 0.32s var(--ease);
    box-shadow: 0 8px 36px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.14);
    position: relative; overflow: hidden;
  }
  #toast::before {
    content: '';
    position: absolute; top: 0; left: 15%; right: 15%; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.28), transparent);
    pointer-events: none;
  }
  #toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }

  /* ── Filter bar ── */
  .filter-bar {
    height: 40px; border-radius: 50px;
    background: linear-gradient(135deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0.03) 100%);
    border: 1px solid var(--lg-border);
    color: var(--text-primary); font-size: 13px; font-family: var(--font);
    padding: 0 16px; outline: none; min-width: 165px;
    transition: all 0.28s var(--ease);
    backdrop-filter: blur(12px);
  }
  .filter-bar:focus { border-color: var(--accent); box-shadow: 0 0 0 2px rgba(48,209,88,0.28); }
  .filter-bar::placeholder { color: var(--text-tertiary); }

  /* ── Falling icons animation (load more) ── */
  .falling-icon {
    position: fixed; pointer-events: none; z-index: 9999;
    font-size: 18px; opacity: 1;
    animation: fall 1s ease-in forwards;
  }
  @keyframes fall {
    0%   { transform: translate(0,0) scale(1); opacity: 1; }
    100% { transform: translate(var(--tx), var(--ty)) scale(0); opacity: 0; }
  }

  /* ════ LIQUID GLASS DISPLACEMENT CANVAS ════
     We'll overlay a canvas on each glass element to simulate
     the SVG feDisplacementMap effect using canvas 2D
  ════════════════════════════════════════════ */
  .lg-displacement {
    position: absolute; inset: 0;
    border-radius: inherit;
    pointer-events: none;
    z-index: 0;
    mix-blend-mode: screen;
    opacity: 0.6;
  }
</style>
</head>
<body>

<!-- SVG filter defs: squircle convex liquid-glass displacement -->
<svg id="lg-filters" xmlns="http://www.w3.org/2000/svg" style="position:absolute;width:0;height:0;overflow:hidden">
  <defs>
    <!-- Main card displacement filter -->
    <filter id="lg-card-filter" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB">
      <feTurbulence type="fractalNoise" baseFrequency="0.65 0.65" numOctaves="1" seed="2" result="noise"/>
      <feColorMatrix type="saturate" values="0" in="noise" result="grayNoise"/>
      <feComposite in="grayNoise" in2="SourceGraphic" operator="in" result="maskedNoise"/>
      <feDisplacementMap in="SourceGraphic" in2="maskedNoise" scale="3" xChannelSelector="R" yChannelSelector="G" result="displaced"/>
      <feBlend in="displaced" in2="SourceGraphic" mode="screen"/>
    </filter>

    <!-- Specular rim filter for player art -->
    <filter id="lg-art-filter" x="-5%" y="-5%" width="110%" height="110%" color-interpolation-filters="sRGB">
      <feGaussianBlur in="SourceAlpha" stdDeviation="2" result="blur"/>
      <feSpecularLighting in="blur" surfaceScale="4" specularConstant="1.2" specularExponent="20" lighting-color="white" result="spec">
        <fePointLight x="40" y="15" z="80"/>
      </feSpecularLighting>
      <feComposite in="spec" in2="SourceAlpha" operator="in" result="specAlpha"/>
      <feBlend in="SourceGraphic" in2="specAlpha" mode="screen"/>
    </filter>

    <!-- Glow filter for active elements -->
    <filter id="lg-glow-filter" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="4" result="glow"/>
      <feBlend in="SourceGraphic" in2="glow" mode="screen"/>
    </filter>

    <!-- Squircle liquid rim specular (for cards on hover) -->
    <filter id="lg-squircle-filter" x="-8%" y="-8%" width="116%" height="116%" color-interpolation-filters="sRGB">
      <feTurbulence type="turbulence" baseFrequency="0.025 0.04" numOctaves="3" seed="5" result="turbNoise"/>
      <feDisplacementMap in="SourceGraphic" in2="turbNoise" scale="6" xChannelSelector="R" yChannelSelector="G"/>
    </filter>
  </defs>
</svg>

<div id="bg"></div>
<div id="app">

  <!-- ════ SIDEBAR ════ -->
  <nav id="sidebar">
    <div class="logo">
      <div class="logo-icon">🎵</div>
      Melodia
    </div>
    <div class="nav-section">
      <div class="nav-btn active" data-frame="home" onclick="showFrame('home',this)">
        <span class="nav-icon">✨</span>Discover
      </div>
      <div class="nav-btn" data-frame="search" onclick="showFrame('search',this)">
        <span class="nav-icon">🔎</span>Search
      </div>
      <div class="nav-btn" data-frame="library" onclick="showFrame('library',this)">
        <span class="nav-icon">📖</span>Library
      </div>
      <div class="nav-btn" data-frame="playlists" onclick="showFrame('playlists',this)">
        <span class="nav-icon">📚</span>Playlists
      </div>
      <div class="nav-btn" data-frame="queue" onclick="showFrame('queue',this)">
        <span class="nav-icon">♊</span>Queue
      </div>
      <div class="nav-btn" data-frame="lyrics" onclick="showFrame('lyrics',this)">
        <span class="nav-icon">🎶</span>Lyrics
      </div>
      <div class="nav-btn" data-frame="settings" onclick="showFrame('settings',this)">
        <span class="nav-icon">⚙️</span>Settings
      </div>
    </div>
    <div class="sidebar-footer">
      <div class="sidebar-label">Theme</div>
      <div class="theme-switcher">
        <div class="theme-select-wrap">
          <select class="theme-select" id="theme-select-sidebar" onchange="setTheme(this.value)">
            <option value="emerald">Emerald</option>
            <option value="aurora">Aurora</option>
            <option value="lavender">Lavender</option>
            <option value="midnight">Midnight</option>
            <option value="sunset">Sunset</option>
            <option value="ocean">Ocean</option>
            <option value="rose">Rose</option>
            <option value="citrus">Citrus</option>
            <option value="ice">Ice</option>
          </select>
        </div>
      </div>
    </div>
  </nav>

  <!-- ════ MAIN ════ -->
  <main id="main">

    <!-- DISCOVER -->
    <div id="frame-home" class="frame active">
      <h1 class="page-title">Discover</h1>
      <div id="discover-loader" class="load-bar"></div>
      <div id="grid-discover"></div>
      <div style="height: 40px; width: 100%; visibility: hidden; pointer-events: none;"></div>
    </div>

    <!-- SEARCH -->
    <div id="frame-search" class="frame">
      <h1 class="page-title">Search</h1>
      <div class="search-bar-wrap">
        <span class="search-icon">⌕</span>
        <input id="search-input" class="search-bar" placeholder="Songs, artists, albums…"
               onkeydown="if(event.key==='Enter') doSearch()"/>
      </div>
      <div id="search-loader" class="load-bar" style="display:none"></div>
      <div id="search-results"></div>
    </div>

    <!-- LIBRARY -->
    <div id="frame-library" class="frame">
      <div class="top-row">
        <h1 class="page-title" style="margin:0">Library</h1>
        <input id="lib-filter" class="filter-bar" placeholder="Filter…" oninput="filterLibrary(this.value)"/>
      </div>
      <div id="grid-library"></div>
    </div>

    <!-- PLAYLISTS -->
    <div id="frame-playlists" class="frame">
      <div class="top-row">
        <h1 class="page-title" style="margin:0">Playlists</h1>
        <button class="btn btn-green" onclick="openCreatePlaylist()">＋ New Playlist</button>
      </div>
      <div id="playlists-list"></div>
    </div>

    <!-- QUEUE -->
    <div id="frame-queue" class="frame">
      <div class="top-row">
        <h1 class="page-title" style="margin:0">Queue</h1>
        <button class="btn btn-danger" onclick="clearQueue()">Clear queue</button>
      </div>
      <div id="queue-list"></div>
    </div>

    <!-- LYRICS -->
    <div id="frame-lyrics" class="frame">
      <h1 class="page-title">Lyrics</h1>
      <div id="lyrics-content">No track playing.</div>
    </div>

    <!-- SETTINGS -->
    <div id="frame-settings" class="frame">
      <h1 class="page-title">Settings</h1>
          <div class="settings-section">
        <div class="settings-title">Appearance</div>
        <div class="settings-row">
          <div>
            <div class="settings-label">Theme preset</div>
            <div class="settings-sublabel">Pick a full visual palette for the whole app</div>
          </div>
          <div class="theme-select-wrap">
            <select class="theme-select" id="theme-select-settings" onchange="setTheme(this.value)">
              <option value="emerald">Emerald</option>
              <option value="aurora">Aurora</option>
              <option value="lavender">Lavender</option>
              <option value="midnight">Midnight</option>
              <option value="sunset">Sunset</option>
              <option value="ocean">Ocean</option>
              <option value="rose">Rose</option>
              <option value="citrus">Citrus</option>
              <option value="ice">Ice</option>
            </select>
          </div>
        </div>
      </div>
      <div class="settings-section" style="margin-top:14px">
        <div class="settings-title">Playback</div>
        <div class="settings-row">
          <div>
            <div class="settings-label">Auto-play</div>
            <div class="settings-sublabel">Play a random song when the queue ends</div>
          </div>
          <label class="toggle-wrap">
            <input type="checkbox" id="set-autoplay" onchange="saveSetting('auto_play', this.checked)"/>
            <span class="toggle-slider"></span>
          </label>
        </div>
        <div class="settings-row">
          <div>
            <div class="settings-label">Run in background</div>
            <div class="settings-sublabel">Minimize to system tray when closing</div>
          </div>
          <label class="toggle-wrap">
            <input type="checkbox" id="set-background" onchange="saveSetting('run_in_background', this.checked)"/>
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>
    </div>
  </main>

  <!-- ════ PLAYER BAR ════ -->
  <div id="player">
    <div class="player-info">
      <div id="player-art">🎵</div>
      <div style="min-width:0">
        <div id="player-title">Nothing playing</div>
        <div id="player-artist" style="font-size:12px;color:var(--text-secondary);margin-top:2px">—</div>
      </div>
    </div>
    <div class="player-center">
      <div class="player-controls">
        <button class="ctrl-btn" onclick="prevHandler()" title="Previous">⏮</button>
        <button id="btn-play-pause" onclick="playPauseHandler()" title="Play/Pause">▶</button>
        <button class="ctrl-btn" onclick="nextHandler()" title="Next">⏭</button>
      </div>
      <div class="timeline">
        <span class="time-label" id="time-current">0:00</span>
        <div class="progress-wrap" id="progress-wrap" onmousedown="startScrub(event)">
          <div class="progress-fill" id="progress-fill" style="width:0%"></div>
        </div>
        <span class="time-label right" id="time-total">0:00</span>
      </div>
    </div>
    <div class="player-right">
      <span class="vol-icon">🔈</span>
      <div class="vol-wrap" onmousedown="startVolScrub(event)" id="vol-wrap">
        <div class="vol-fill" id="vol-fill" style="width:100%"></div>
      </div>
    </div>
  </div>

</div>

<!-- ════ CREATE PLAYLIST MODAL ════ -->
<div class="modal-backdrop" id="modal-backdrop" onclick="if(event.target===this)closeModal()">
  <div class="modal">
    <div class="modal-title">New Playlist</div>
    <input id="pl-name-input" class="modal-input" placeholder="Playlist name…"/>
    <div class="modal-body" id="pl-tracks-list"></div>
    <div style="display:flex;gap:10px;position:relative;z-index:1">
      <button class="btn btn-glass" style="flex:1" onclick="closeModal()">Cancel</button>
      <button class="btn btn-green" style="flex:1" onclick="savePlaylist()">Save</button>
    </div>
  </div>
</div>

<!-- TOAST -->
<div id="toast"></div>

<script>
// ══════════════════════════════════════════════════════
//  LIQUID GLASS ENGINE
//  Physics-based SVG displacement map + specular highlight
//  Implements squircle convex bezel from kube.io method
// ══════════════════════════════════════════════════════

const LiquidGlass = (() => {
  const IOR = 1.5;   // glass refractive index
  const BEZEL_SAMPLES = 127; // must match SVG 8-bit resolution

  // Squircle convex height function (Apple-style smooth bezel)
  function squircleConvex(x) {
    return Math.pow(1 - Math.pow(1 - x, 4), 0.25);
  }

  // Approximate derivative for normal calculation
  function derivative(f, x, delta = 0.001) {
    return (f(x + delta) - f(x - delta)) / (2 * delta);
  }

  // Snell-Descartes refraction: returns [sin_t2, cos_t2]
  function snell(sin_i, n1, n2) {
    const sin_t = (n1 / n2) * sin_i;
    if (Math.abs(sin_t) > 1) return null; // total internal reflection
    return [sin_t, Math.sqrt(1 - sin_t * sin_t)];
  }

  // Pre-compute displacement magnitudes along one radius
  function buildRadiusDisplacements(bezelFraction, glassThickness) {
    const mags = [];
    for (let i = 0; i < BEZEL_SAMPLES; i++) {
      const t = i / (BEZEL_SAMPLES - 1); // 0..1 distance into bezel
      const x = t; // normalised distance from edge

      // Height of glass surface at this point
      const h = squircleConvex(x) * glassThickness;

      // Surface normal (derivative of height, rotated -90°)
      const dh = derivative(squircleConvex, x) * glassThickness;
      // normal = (-dh, 1) normalised
      const nLen = Math.sqrt(dh * dh + 1);
      const nx = -dh / nLen;
      const ny = 1 / nLen;

      // Incident ray: straight down (0, 1)
      // Angle of incidence: angle between ray and normal
      const cos_i = ny; // dot product of (0,1) and normal
      const sin_i = Math.abs(nx);

      // Refracted direction
      const ref = snell(sin_i, 1.0, IOR);
      if (!ref) { mags.push(0); continue; }
      const [sin_t, cos_t] = ref;

      // Lateral displacement: difference between incident and refracted paths
      const dispX = sin_t * h - sin_i * h;
      mags.push(dispX * (nx < 0 ? -1 : 1));
    }
    return mags;
  }

  // Generate displacement map canvas for a rounded-rect element
  function generateDisplacementMap(width, height, radius, bezelFraction, glassThickness) {
    const canvas = document.createElement('canvas');
    canvas.width  = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    const data = ctx.createImageData(width, height);
    const px = data.data;

    const bezelW = Math.min(width, height) * bezelFraction;
    const mags = buildRadiusDisplacements(bezelFraction, glassThickness);
    const maxMag = Math.max(...mags.map(Math.abs), 0.001);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        // Distance to nearest edge
        const dx = Math.min(x, width  - 1 - x);
        const dy = Math.min(y, height - 1 - y);
        const distToEdge = Math.min(dx, dy);

        let rx = 128, ry = 128, alpha = 0;

        if (distToEdge < bezelW) {
          // normalised position into bezel (0=edge,1=interior)
          const t = distToEdge / bezelW;
          const idx = Math.min(Math.floor(t * BEZEL_SAMPLES), BEZEL_SAMPLES - 1);
          const mag = mags[idx] / maxMag; // normalised [-1,1]

          // Direction pointing inward from nearest edge
          const ax = dx < dy ? (x < width  / 2 ? -1 : 1) : 0;
          const ay = dy < dx ? (y < height / 2 ? -1 : 1) : 0;
          // diagonal corners: blend
          const nx2 = dx < dy ? ax : (dx === dy ? ax : 0);
          const ny2 = dy < dx ? ay : (dx === dy ? ay : 0);
          const len = Math.sqrt(nx2 * nx2 + ny2 * ny2) || 1;

          rx = Math.round(128 + (nx2 / len) * mag * 127);
          ry = Math.round(128 + (ny2 / len) * mag * 127);
          alpha = 255;
        }

        const i = (y * width + x) * 4;
        px[i]   = Math.max(0, Math.min(255, rx));
        px[i+1] = Math.max(0, Math.min(255, ry));
        px[i+2] = 128;
        px[i+3] = alpha;
      }
    }

    ctx.putImageData(data, 0, 0);
    return canvas.toDataURL();
  }

  // Generate specular highlight image (rim + dome)
  function generateSpecular(width, height, radius, specularAngle = -55) {
    const canvas = document.createElement('canvas');
    canvas.width  = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    // Rim specular (bright edge band)
    const rimW = Math.max(width, height) * 0.08;
    const rimAngle = (specularAngle * Math.PI) / 180;
    const lx = Math.cos(rimAngle);
    const ly = Math.sin(rimAngle);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const nx2 = (x / width)  * 2 - 1;
        const ny2 = (y / height) * 2 - 1;
        // dot with light direction
        const proj = nx2 * lx + ny2 * ly;
        // distance to edge
        const distToEdge = Math.min(x, width - 1 - x, y, height - 1 - y);
        const rimFactor   = Math.exp(-distToEdge / rimW);
        const specFactor  = Math.pow(Math.max(0, proj), 3) * rimFactor;
        const alpha = Math.min(255, specFactor * 180);
        const i = (y * width + x) * 4;
        ctx.fillStyle = `rgba(255,255,255,${alpha/255})`;
      }
    }

    // Dome highlight (top-left radial)
    const grad = ctx.createRadialGradient(
      width * 0.3, height * 0.28, 0,
      width * 0.3, height * 0.28, Math.max(width, height) * 0.55
    );
    grad.addColorStop(0,   'rgba(255,255,255,0.22)');
    grad.addColorStop(0.45,'rgba(255,255,255,0.06)');
    grad.addColorStop(1,   'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(0, 0, width, height, radius);
    ctx.fill();

    // Top rim line
    const rimGrad = ctx.createLinearGradient(0, 0, width, 0);
    rimGrad.addColorStop(0,   'rgba(255,255,255,0)');
    rimGrad.addColorStop(0.35,'rgba(255,255,255,0.38)');
    rimGrad.addColorStop(0.65,'rgba(255,255,255,0.38)');
    rimGrad.addColorStop(1,   'rgba(255,255,255,0)');
    ctx.fillStyle = rimGrad;
    ctx.fillRect(0, 0, width, 1);

    return canvas.toDataURL();
  }

  // Apply liquid glass SVG filter to element
  function applyToElement(el, opts = {}) {
    const {
      bezelFraction = 0.22,
      glassThickness = 0.28,
      specularOpacity = 0.72,
      specularAngle = -55,
    } = opts;

    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const w = Math.round(rect.width);
    const h = Math.round(rect.height);
    const r = parseFloat(getComputedStyle(el).borderRadius) || 14;

    // Inject SVG filter for this element
    const filterId = `lg-filter-${Math.random().toString(36).slice(2)}`;
    const dispMapUrl = generateDisplacementMap(w, h, r, bezelFraction, glassThickness);
    const specMapUrl = generateSpecular(w, h, r, specularAngle);
    const maxDisp = glassThickness * 18; // px

    const svgNS = 'http://www.w3.org/2000/svg';
    const defs  = document.getElementById('lg-filters').querySelector('defs');

    const filter = document.createElementNS(svgNS, 'filter');
    filter.setAttribute('id', filterId);
    filter.setAttribute('x', '-5%'); filter.setAttribute('y', '-5%');
    filter.setAttribute('width', '110%'); filter.setAttribute('height', '110%');
    filter.setAttribute('color-interpolation-filters', 'sRGB');

    filter.innerHTML = `
      <feImage href="${dispMapUrl}" x="0" y="0" width="${w}" height="${h}" result="dispMap" preserveAspectRatio="none"/>
      <feDisplacementMap in="SourceGraphic" in2="dispMap"
        scale="${maxDisp}" xChannelSelector="R" yChannelSelector="G" result="refracted"/>
      <feImage href="${specMapUrl}" x="0" y="0" width="${w}" height="${h}" result="specular" preserveAspectRatio="none"/>
      <feBlend in="refracted" in2="specular" mode="screen" result="combined"/>
      <feComposite in="combined" in2="SourceGraphic" operator="atop"/>
    `;
    defs.appendChild(filter);

    // Apply via backdrop-filter (Chrome) with fallback to filter
    el.style.setProperty('backdrop-filter', `blur(24px) saturate(200%) url(#${filterId})`);
    el.style.setProperty('-webkit-backdrop-filter', `blur(24px) saturate(200%) url(#${filterId})`);
    el._lgFilterId = filterId;
  }

  // Lightweight version: just adds specular canvas overlay
  function addSpecularOverlay(el, opts = {}) {
    const { specularOpacity = 0.65, specularAngle = -55 } = opts;
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const w = Math.round(rect.width);
    const h = Math.round(rect.height);
    const r = parseFloat(getComputedStyle(el).borderRadius) || 14;

    const existing = el.querySelector('.lg-spec-overlay');
    if (existing) existing.remove();

    const canvas = document.createElement('canvas');
    canvas.className = 'lg-spec-overlay';
    canvas.width  = w;
    canvas.height = h;
    canvas.style.cssText = `
      position:absolute;inset:0;width:100%;height:100%;
      border-radius:inherit;pointer-events:none;z-index:0;
      opacity:${specularOpacity};mix-blend-mode:screen;
    `;

    const ctx = canvas.getContext('2d');
    const grad = ctx.createRadialGradient(w * 0.28, h * 0.26, 0, w * 0.28, h * 0.26, Math.max(w, h) * 0.58);
    grad.addColorStop(0,    'rgba(255,255,255,0.2)');
    grad.addColorStop(0.42, 'rgba(255,255,255,0.055)');
    grad.addColorStop(1,    'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(0, 0, w, h, r);
    else ctx.rect(0, 0, w, h);
    ctx.fill();

    // top rim
    const rimGrad = ctx.createLinearGradient(0, 0, w, 0);
    rimGrad.addColorStop(0,    'rgba(255,255,255,0)');
    rimGrad.addColorStop(0.32, 'rgba(255,255,255,0.36)');
    rimGrad.addColorStop(0.68, 'rgba(255,255,255,0.36)');
    rimGrad.addColorStop(1,    'rgba(255,255,255,0)');
    ctx.fillStyle = rimGrad;
    ctx.fillRect(0, 0, w, 1);

    // side rim sparkle
    const sideGrad = ctx.createLinearGradient(0, 0, 0, h);
    sideGrad.addColorStop(0,   'rgba(255,255,255,0.14)');
    sideGrad.addColorStop(0.5, 'rgba(255,255,255,0.04)');
    sideGrad.addColorStop(1,   'rgba(255,255,255,0.08)');
    ctx.fillStyle = sideGrad;
    ctx.fillRect(0, 0, 1, h);
    ctx.fillRect(w - 1, 0, 1, h);

    el.appendChild(canvas);
  }

  // Initialise all glass elements on the page
  function init() {
    // Add specular overlays to cards (lighter approach, works everywhere)
    document.querySelectorAll('.disc-card, .lib-card, .glass-card').forEach(el => {
      requestAnimationFrame(() => addSpecularOverlay(el, { specularOpacity: 0.68 }));
    });
    document.querySelectorAll('.search-row, .pl-row, .q-row').forEach(el => {
      requestAnimationFrame(() => addSpecularOverlay(el, { specularOpacity: 0.45 }));
    });
    // Settings sections
    document.querySelectorAll('.settings-section').forEach(el => {
      requestAnimationFrame(() => addSpecularOverlay(el, { specularOpacity: 0.38 }));
    });
  }

  // Re-run on dynamic DOM additions
  function observe() {
    const observer = new MutationObserver(muts => {
      muts.forEach(m => {
        m.addedNodes.forEach(node => {
          if (!(node instanceof Element)) return;
          const targets = [
            ...node.querySelectorAll('.disc-card, .lib-card, .glass-card'),
            ...node.querySelectorAll('.search-row, .pl-row, .q-row'),
          ];
          if (node.classList && (
            node.classList.contains('disc-card') ||
            node.classList.contains('lib-card') ||
            node.classList.contains('search-row') ||
            node.classList.contains('pl-row') ||
            node.classList.contains('q-row')
          )) targets.push(node);
          targets.forEach(el => {
            setTimeout(() => addSpecularOverlay(el, {
              specularOpacity: el.classList.contains('search-row') ||
                               el.classList.contains('pl-row') ||
                               el.classList.contains('q-row') ? 0.42 : 0.68
            }), 30);
          });
        });
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  return { init, observe, addSpecularOverlay, generateSpecular };
})();

// ══════════════ STATE ══════════════
let currentFrame = 'home';
let isPlaying = false;
let isPaused = false;
let trackDuration = 0;
let currentPosition = 0;
let isScrubbing = false;
let lastTimestamp = null;
let animFrame = null;
let volume = 1.0;

function setTheme(themeName) {
  const validThemes = ['emerald', 'aurora', 'lavender', 'midnight', 'sunset', 'ocean', 'rose', 'citrus', 'ice'];
  const resolved = validThemes.includes(themeName) ? themeName : 'emerald';
  document.documentElement.setAttribute('data-theme', resolved);
  document.querySelectorAll('.theme-select').forEach(select => select.value = resolved);
  document.querySelectorAll('.theme-chip').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === resolved);
  });
  try { localStorage.setItem('melodia-theme', resolved); } catch (e) {}
}

function initTheme() {
  let stored = 'emerald';
  try { stored = localStorage.getItem('melodia-theme') || 'emerald'; } catch (e) {}
  setTheme(stored);
}

initTheme();

// ══════════════ NAVIGATION ══════════════
function showFrame(name, el) {
  document.querySelectorAll('.frame').forEach(f => f.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('frame-' + name).classList.add('active');
  if (el) el.classList.add('active');
  currentFrame = name;
  if (name === 'library')   refreshLibrary();
  if (name === 'playlists') refreshPlaylists();
  if (name === 'queue')     refreshQueue();
}

// ══════════════ PYTHON BRIDGE ══════════════
async function pyApi(method, ...args) {
  try { return await window.pywebview.api[method](...args); }
  catch(e) { console.error('pyApi error:', method, e); }
}

// ══════════════ TOAST ══════════════
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2400);
}

// ══════════════ DISCOVER ══════════════
async function loadDiscover() {
  const grid   = document.getElementById('grid-discover');
  const loader = document.getElementById('discover-loader');
  grid.innerHTML = '';
  loader.style.display = 'block';
  const results = await pyApi('get_recommendations');
  loader.style.display = 'none';
  if (!results || !results.length) {
    grid.innerHTML = '<div class="empty-state"><h3>No recommendations</h3><p>Add some songs to your library first</p></div>';
    return;
  }
  results.forEach(t => {
    const card = document.createElement('div');
    card.className = 'disc-card';
    const thumbUrl = t.thumb || '';
    card.innerHTML = `
      <div class="disc-art" id="da-${t.video_id || Math.random().toString(36).slice(2)}">
        ${thumbUrl ? `<img src="${thumbUrl}" onerror="this.style.display='none'" loading="lazy"/>` : '🎵'}
      </div>
      <div class="disc-title">${escHtml(t.title)}</div>
      <div class="disc-artist">${escHtml(t.artist)}</div>`;
    card.onclick = () => { pyApi('cloud_play', t.video_id, t.title, t.artist, t.thumb); toast('Loading · ' + t.title); };
    grid.appendChild(card);
  });
}

// infinite scroll
document.getElementById('frame-home').addEventListener('scroll', function() {
  if (this.scrollTop + this.clientHeight >= this.scrollHeight - 100) loadMoreDiscover();
});
let loadingMore = false;

async function loadMoreDiscover() {
  if (loadingMore) return;
  loadingMore = true;
  const more = await pyApi('get_more_recommendations');
  loadingMore = false;
  if (!more || !more.length) return;
  const grid = document.getElementById('grid-discover');
  more.forEach(t => {
    const card = document.createElement('div');
    card.className = 'disc-card';
    const thumbUrl = t.thumb || '';
    card.innerHTML = `
      <div class="disc-art">${thumbUrl ? `<img src="${thumbUrl}" onerror="this.style.display='none'" loading="lazy"/>` : '🎵'}</div>
      <div class="disc-title">${escHtml(t.title)}</div>
      <div class="disc-artist">${escHtml(t.artist)}</div>`;
    card.onclick = () => { pyApi('cloud_play', t.video_id, t.title, t.artist, t.thumb); toast('Loading · ' + t.title); };
    grid.appendChild(card);
  });
}

// ══════════════ SEARCH ══════════════
async function doSearch() {
  const q      = document.getElementById('search-input').value.trim();
  if (!q) return;
  const res    = document.getElementById('search-results');
  const loader = document.getElementById('search-loader');
  res.innerHTML = '';
  loader.style.display = 'block';
  const results = await pyApi('search_songs', q);
  loader.style.display = 'none';
  if (!results || !results.length) {
    res.innerHTML = '<div class="empty-state"><h3>No results</h3><p>Try a different search</p></div>';
    return;
  }
  results.forEach(t => {
    const row = document.createElement('div');
    row.className = 'search-row';
    const thumbUrl = t.thumb || '';
    row.innerHTML = `
      <div class="search-thumb">
        ${thumbUrl ? `<img src="${thumbUrl}" onerror="this.parentNode.textContent='🎵'" loading="lazy"/>` : '🎵'}
      </div>
      <div class="search-info">
        <div class="search-title">${escHtml(t.title)}</div>
        <div class="search-meta">${escHtml(t.artist)} · ${t.duration || ''}</div>
      </div>
      <button class="btn btn-green" style="flex-shrink:0;padding:7px 15px;font-size:12px"
              onclick="event.stopPropagation();pyApi('cloud_play','${t.video_id}','${escJs(t.title)}','${escJs(t.artist)}','${escJs(thumbUrl)}');toast('Loading · ${escJs(t.title)}')">
        ▶ Play
      </button>`;
    row.onclick = () => { pyApi('cloud_play', t.video_id, t.title, t.artist, thumbUrl); toast('Loading · ' + t.title); };
    res.appendChild(row);
  });
}

// ══════════════ LIBRARY ══════════════
let libraryData = [];
async function refreshLibrary() {
  const grid = document.getElementById('grid-library');
  grid.innerHTML = '<div class="spinner"></div>';
  libraryData = await pyApi('get_library') || [];
  renderLibrary(libraryData);
}
function filterLibrary(q) {
  const filtered = q ? libraryData.filter(t => (t.title+t.artist).toLowerCase().includes(q.toLowerCase())) : libraryData;
  renderLibrary(filtered);
}
function renderLibrary(tracks) {
  const grid = document.getElementById('grid-library');
  if (!tracks.length) {
    grid.innerHTML = '<div class="empty-state"><h3>No songs yet</h3><p>Search and play songs to download them</p></div>';
    return;
  }
  grid.innerHTML = '';
  tracks.forEach(t => {
    const card = document.createElement('div');
    card.className = 'lib-card';
    const isFav = t.is_fav;
    card.innerHTML = `
      <div class="lib-art">${t.art_b64 ? `<img src="data:image/jpeg;base64,${t.art_b64}"/>` : '🎵'}</div>
      <div class="lib-title">${escHtml(t.title)}</div>
      <div class="lib-artist">${escHtml(t.artist)}</div>
      <div class="lib-actions">
        <button class="lib-btn ${isFav?'fav-active':''}" title="Favourite"
                onclick="toggleFav('${escJs(t.filename)}',this)">♥</button>
        <button class="lib-btn green" title="Play"
                onclick="pyApi('play_local','${escJs(t.filename)}');toast('▶ ${escJs(t.title)}')">▶</button>
        <button class="lib-btn blue" title="Add to queue"
                onclick="pyApi('enqueue_local','${escJs(t.filename)}');toast('Added to queue')">➕</button>
        <button class="lib-btn red" title="Delete"
                onclick="confirmDelete('${escJs(t.filename)}','${escJs(t.title)}')">🗑</button>
      </div>`;
    grid.appendChild(card);
  });
}
async function toggleFav(filename, btn) {
  await pyApi('toggle_favorite', filename);
  btn.classList.toggle('fav-active');
}
async function confirmDelete(filename, title) {
  if (confirm('Delete "' + title + '"? This cannot be undone.')) {
    await pyApi('delete_track', filename);
    toast('Deleted · ' + title);
    refreshLibrary();
  }
}

// ══════════════ PLAYLISTS ══════════════
async function refreshPlaylists() {
  const list = document.getElementById('playlists-list');
  list.innerHTML = '<div class="spinner"></div>';
  const data  = await pyApi('get_playlists') || {};
  list.innerHTML = '';
  const names = Object.keys(data);
  if (!names.length) {
    list.innerHTML = '<div class="empty-state"><h3>No playlists yet</h3><p>Create your first playlist above</p></div>';
    return;
  }
  names.forEach(name => {
    const tracks = data[name];
    const row = document.createElement('div');
    row.className = 'pl-row';
    row.innerHTML = `
      <div class="pl-art">🗂️</div>
      <div class="pl-info">
        <div class="pl-name">${escHtml(name)}</div>
        <div class="pl-meta">${tracks.length} tracks</div>
      </div>
      <div class="pl-btns">
        <button class="btn btn-green" onclick="pyApi('play_playlist','${escJs(name)}');toast('Playing ${escJs(name)}')">▶ Play</button>
        <button class="btn btn-danger" onclick="deletePlaylist('${escJs(name)}')">Delete</button>
      </div>`;
    list.appendChild(row);
  });
}
async function deletePlaylist(name) {
  if (confirm('Delete playlist "' + name + '"?')) {
    await pyApi('delete_playlist', name);
    toast('Playlist deleted');
    refreshPlaylists();
  }
}
function openCreatePlaylist() {
  document.getElementById('pl-name-input').value = '';
  loadModalTracks();
  document.getElementById('modal-backdrop').classList.add('show');
}
async function loadModalTracks() {
  const list = document.getElementById('pl-tracks-list');
  list.innerHTML = '<div class="spinner"></div>';
  const tracks = await pyApi('get_library') || [];
  list.innerHTML = '';
  tracks.forEach(t => {
    const div = document.createElement('label');
    div.className = 'modal-check';
    div.innerHTML = `<input type="checkbox" value="${escHtml(t.filename)}"/> ${escHtml(t.title)} — ${escHtml(t.artist)}`;
    list.appendChild(div);
  });
}
function closeModal() { document.getElementById('modal-backdrop').classList.remove('show'); }
async function savePlaylist() {
  const name = document.getElementById('pl-name-input').value.trim();
  if (!name) { toast('Enter a playlist name'); return; }
  const checks = document.querySelectorAll('#pl-tracks-list input:checked');
  const files  = Array.from(checks).map(c => c.value);
  await pyApi('create_playlist', name, files);
  toast('Playlist created · ' + name);
  closeModal();
  if (currentFrame === 'playlists') refreshPlaylists();
}

// ══════════════ QUEUE ══════════════
async function refreshQueue() {
  const list = document.getElementById('queue-list');
  const data = await pyApi('get_queue') || { queue: [], idx: -1 };
  list.innerHTML = '';
  if (!data.queue.length) {
    list.innerHTML = '<div class="empty-state"><h3>Queue is empty</h3><p>Play a song to get started</p></div>';
    return;
  }
  data.queue.forEach((t, i) => {
    const isCurrent = i === data.idx;
    const row = document.createElement('div');
    row.className = 'q-row' + (isCurrent ? ' current-track' : '');
    row.innerHTML = `
      <div class="q-num ${isCurrent ? 'playing' : ''}">${isCurrent ? '▶' : i+1}</div>
      <div class="q-art">${t.art_b64 ? `<img src="data:image/jpeg;base64,${t.art_b64}"/>` : '🎵'}</div>
      <div class="q-info">
        <div class="q-title">${escHtml(t.title)}</div>
        <div class="q-artist">${escHtml(t.artist)}</div>
      </div>
      ${!isCurrent ? `<button class="lib-btn" style="flex:0;width:28px;height:28px" onclick="event.stopPropagation();pyApi('remove_from_queue',${i});setTimeout(refreshQueue,100)">✕</button>` : ''}`;
    if (!isCurrent) row.onclick = () => { pyApi('jump_to', i); setTimeout(() => { refreshQueue(); updatePlayerUI(); }, 200); };
    list.appendChild(row);
  });
}
async function clearQueue() {
  await pyApi('clear_queue');
  toast('Queue cleared');
  refreshQueue();
}

// ══════════════ LYRICS ══════════════
function updateLyrics(text) {
  document.getElementById('lyrics-content').textContent = text || 'No lyrics available.';
}

// ══════════════ SETTINGS ══════════════
async function loadSettings() {
  const s = await pyApi('get_settings') || {};
  document.getElementById('set-autoplay').checked   = !!s.auto_play;
  document.getElementById('set-background').checked = !!s.run_in_background;
}
async function saveSetting(key, val) { await pyApi('save_setting', key, val); }

// ══════════════ PLAYER UI ══════════════
async function updatePlayerUI() {
  const state = await pyApi('get_player_state');
  if (!state) return;
  isPlaying = state.is_playing;
  isPaused  = state.is_paused;
  trackDuration   = state.duration  || 0;
  currentPosition = state.position  || 0;
  document.getElementById('player-title').textContent  = state.title  || 'Nothing playing';
  document.getElementById('player-artist').textContent = state.artist || '—';
  document.getElementById('btn-play-pause').textContent = (isPlaying && !isPaused) ? '⏸' : '▶';
  document.getElementById('time-total').textContent = formatTime(trackDuration);
  if (state.art_b64) {
    document.getElementById('player-art').innerHTML = `<img src="data:image/jpeg;base64,${state.art_b64}" style="width:100%;height:100%;object-fit:cover;border-radius:11px"/>`;
  } else {
    document.getElementById('player-art').textContent = '🎵';
  }
  if (currentFrame === 'queue') refreshQueue();
}

// ══════════════ RESPONSIVE BUTTON HANDLERS ══════════════
async function playPauseHandler() {
  const btn = document.getElementById('btn-play-pause');
  const wasPlaying = isPlaying && !isPaused;
  btn.textContent = wasPlaying ? '▶' : '⏸';
  isPaused = !isPaused;
  await pyApi('toggle_pause');
  setTimeout(() => updatePlayerUI(), 300);
}

async function nextHandler() {
  const btn = document.querySelector('[onclick="nextHandler()"]');
  btn.style.opacity   = '0.6';
  btn.style.transform = 'scale(0.92)';
  await pyApi('next');
  setTimeout(() => { updatePlayerUI(); btn.style.opacity = '1'; btn.style.transform = 'scale(1)'; }, 300);
}

async function prevHandler() {
  const btn = document.querySelector('[onclick="prevHandler()"]');
  btn.style.opacity   = '0.6';
  btn.style.transform = 'scale(0.92)';
  await pyApi('prev');
  setTimeout(() => { updatePlayerUI(); btn.style.opacity = '1'; btn.style.transform = 'scale(1)'; }, 300);
}

// Smooth progress via rAF
function tickProgress(ts) {
  if (isPlaying && !isPaused && !isScrubbing && trackDuration > 0) {
    if (lastTimestamp !== null) {
      currentPosition += (ts - lastTimestamp) / 1000;
      if (currentPosition > trackDuration) currentPosition = trackDuration;
    }
    lastTimestamp = ts;
    const pct = trackDuration > 0 ? (currentPosition / trackDuration * 100) : 0;
    document.getElementById('progress-fill').style.width = pct + '%';
    document.getElementById('time-current').textContent  = formatTime(currentPosition);
  } else {
    lastTimestamp = null;
  }
  animFrame = requestAnimationFrame(tickProgress);
}
requestAnimationFrame(tickProgress);

// Sync from Python every 2s
setInterval(async () => {
  const state = await pyApi('get_player_state');
  if (!state) return;
  isPlaying = state.is_playing;
  isPaused  = state.is_paused;
  trackDuration = state.duration || 0;
  if (!isScrubbing) currentPosition = state.position || 0;
  const titleEl = document.getElementById('player-title');
  if (titleEl.textContent !== (state.title || 'Nothing playing')) {
    titleEl.textContent = state.title || 'Nothing playing';
    document.getElementById('player-artist').textContent = state.artist || '—';
    document.getElementById('btn-play-pause').textContent = (isPlaying && !isPaused) ? '⏸' : '▶';
    document.getElementById('time-total').textContent = formatTime(trackDuration);
    if (state.art_b64) {
      document.getElementById('player-art').innerHTML = `<img src="data:image/jpeg;base64,${state.art_b64}" style="width:100%;height:100%;object-fit:cover;border-radius:11px"/>`;
    } else {
      document.getElementById('player-art').textContent = '🎵';
    }
    if (state.lyrics) updateLyrics(state.lyrics);
  }
  if (!isScrubbing) {
    currentPosition = typeof state.position === 'number' ? state.position : currentPosition;
    const pct = trackDuration > 0 ? (currentPosition / trackDuration * 100) : 0;
    document.getElementById('progress-fill').style.width = pct + '%';
    document.getElementById('time-current').textContent  = formatTime(currentPosition);
  }
  document.getElementById('btn-play-pause').textContent = (isPlaying && !isPaused) ? '⏸' : '▶';
}, 2000);

// ══════════════ SCRUBBING ══════════════
let scrubActive = false;
function startScrub(e) {
  scrubActive = true; isScrubbing = true;
  doScrub(e);
  const onMove = ev => doScrub(ev);
  const onUp   = ev => {
    doScrub(ev); scrubActive = false;
    const wrap = document.getElementById('progress-wrap');
    const rect = wrap.getBoundingClientRect();
    const pct  = Math.max(0, Math.min(1, (ev.clientX - rect.left) / rect.width));
    pyApi('seek', pct * trackDuration);
    setTimeout(() => { isScrubbing = false; lastTimestamp = null; }, 300);
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup',   onUp);
  };
  document.addEventListener('mousemove', onMove);
  document.addEventListener('mouseup',   onUp);
}
function doScrub(e) {
  if (!scrubActive) return;
  const wrap = document.getElementById('progress-wrap');
  const rect = wrap.getBoundingClientRect();
  const pct  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  currentPosition = pct * trackDuration;
  document.getElementById('progress-fill').style.width = (pct * 100) + '%';
  document.getElementById('time-current').textContent  = formatTime(currentPosition);
}

// ══════════════ VOLUME ══════════════
let volScrubbing = false;
function startVolScrub(e) {
  volScrubbing = true;
  doVol(e);
  const onMove = ev => doVol(ev);
  const onUp   = ev => { doVol(ev); volScrubbing = false; document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); };
  document.addEventListener('mousemove', onMove);
  document.addEventListener('mouseup',   onUp);
}
function doVol(e) {
  if (!volScrubbing) return;
  const wrap = document.getElementById('vol-wrap');
  const rect = wrap.getBoundingClientRect();
  volume = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  document.getElementById('vol-fill').style.width = (volume * 100) + '%';
  pyApi('set_volume', volume);
}

// ══════════════ BG PARALLAX ══════════════
document.addEventListener('mousemove', e => {
  const x = (e.clientX / window.innerWidth  * 100).toFixed(1);
  const y = (e.clientY / window.innerHeight * 100).toFixed(1);
  document.getElementById('bg').style.setProperty('--mx', x + '%');
  document.getElementById('bg').style.setProperty('--my', y + '%');
});

// ══════════════ HELPERS ══════════════
function formatTime(s) {
  if (!s || s < 0) return '0:00';
  const m   = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2,'0')}`;
}
function escHtml(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function escJs(s) {
  return String(s||'').replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/"/g,'\\"');
}

// ══════════════ INIT ══════════════
window.addEventListener('pywebviewready', async () => {
  initTheme();
  loadDiscover();
  loadSettings();
  updatePlayerUI();
  // Init liquid glass engine after a tick
  setTimeout(() => { LiquidGlass.init(); LiquidGlass.observe(); }, 100);
});
// fallback
setTimeout(() => {
  if (window.pywebview) {
    loadDiscover();
    loadSettings();
    updatePlayerUI();
  }
  setTimeout(() => { LiquidGlass.init(); LiquidGlass.observe(); }, 200);
}, 800);

</script>
</body>
</html>
"""



# ─── PYTHON API (exposed to JS) ────────────────────────────────────────────────
class MelodiaAPI:
    def __init__(self, app):
        self.app = app

    # ── Player controls ──
    def toggle_pause(self):
        self.app.toggle_pause()

    def next(self):
        self.app.play_next()

    def prev(self):
        self.app.play_prev()

    def seek(self, seconds):
        self.app.seek(float(seconds))

    def set_volume(self, vol):
        pygame.mixer.music.set_volume(float(vol))

    def clear_queue(self):
        self.app.stop_music()
        self.app.queue = []
        self.app.current_queue_idx = -1

    def remove_from_queue(self, index):
        self.app.remove_from_queue(int(index))

    def jump_to(self, index):
        self.app.jump_to_queue_index(int(index))

    def get_player_state(self):
        a = self.app
        art_b64 = None
        if a.queue and a.current_queue_idx >= 0:
            track = a.queue[a.current_queue_idx]
            art_b64 = _get_art_b64(track, a.download_dir)
        return {
            'is_playing': a.is_playing,
            'is_paused': a.is_paused,
            'title': a.current_title,
            'artist': a.current_artist,
            'duration': a.track_duration,
            'position': a.current_position,
            'art_b64': art_b64,
            'lyrics': getattr(a, '_cached_lyrics', None),
        }

    # ── Discovery ──
    def get_recommendations(self):
        return self.app.get_recommendations()

    def get_more_recommendations(self):
        return self.app.get_more_recommendations()

    # ── Search ──
    def search_songs(self, query):
        try:
            results = self.app.yt_api.search(query, filter="songs")[:15]
            out = []
            for t in results:
                thumb_list = t.get("thumbnails") or t.get("thumbnail") or []
                thumb = thumb_list[-1].get("url") if isinstance(thumb_list, list) and thumb_list else None
                out.append({
                    'title': t.get('title', 'Unknown'),
                    'artist': (t.get('artists') or [{}])[0].get('name', 'Unknown'),
                    'duration': t.get('duration', ''),
                    'video_id': t.get('videoId', ''),
                    'thumb': thumb,
                })
            return out
        except Exception as e:
            print(f"Search error: {e}")
            return []

    # ── Library ──
    def get_library(self):
        a = self.app
        if not os.path.exists(a.download_dir):
            return []
        files = [f for f in os.listdir(a.download_dir) if f.endswith('.mp3')]
        files.sort(key=lambda x: (x not in a.favorites, x.lower()))
        out = []
        for f in files:
            base = os.path.splitext(f)[0]
            parts = base.split('-')
            title = parts[0].strip()
            artist = parts[1].strip() if len(parts) > 1 else 'Unknown'
            jpg = os.path.join(a.download_dir, f"{base}.jpg")
            art_b64 = _img_to_b64(jpg, (140, 140)) if os.path.exists(jpg) else None
            out.append({
                'filename': f,
                'title': title,
                'artist': artist,
                'is_fav': f in a.favorites,
                'art_b64': art_b64,
            })
        return out

    def toggle_favorite(self, filename):
        a = self.app
        if filename in a.favorites:
            a.favorites.remove(filename)
        else:
            a.favorites.append(filename)
        a._save_user_data()

    def play_local(self, filename):
        a = self.app
        full = os.path.join(a.download_dir, filename)
        base = os.path.splitext(filename)[0]
        parts = base.split('-')
        title = parts[0].strip()
        artist = parts[1].strip() if len(parts) > 1 else 'Unknown'
        track = {'title': title, 'artist': artist, 'path': full, 'img_url': None, 'video_id': None}
        a.queue_and_play(track)

    def enqueue_local(self, filename):
        a = self.app
        full = os.path.join(a.download_dir, filename)
        base = os.path.splitext(filename)[0]
        parts = base.split('-')
        title = parts[0].strip()
        artist = parts[1].strip() if len(parts) > 1 else 'Unknown'
        track = {'title': title, 'artist': artist, 'path': full, 'img_url': None, 'video_id': None}
        a.queue.append(track)

    def delete_track(self, filename):
        a = self.app
        mp3 = os.path.join(a.download_dir, filename)
        # Stop if playing this track
        if a.is_playing and a.current_queue_idx >= 0:
            active = a.queue[a.current_queue_idx]
            if os.path.normpath(active['path']) == os.path.normpath(mp3):
                a.stop_music()
        try:
            pygame.mixer.music.unload()
            if os.path.exists(mp3):
                os.remove(mp3)
            jpg = os.path.splitext(mp3)[0] + '.jpg'
            if os.path.exists(jpg):
                os.remove(jpg)
            if filename in a.favorites:
                a.favorites.remove(filename)
                a._save_user_data()
        except Exception as e:
            print(f"Delete error: {e}")

    # ── Cloud play ──
    def cloud_play(self, video_id, title, artist, image_url):
        self.app.handle_cloud_play(video_id, title, artist, image_url)

    # ── Playlists ──
    def get_playlists(self):
        return self.app.playlists

    def create_playlist(self, name, files):
        self.app.playlists[name] = files
        self.app._save_user_data()

    def delete_playlist(self, name):
        if name in self.app.playlists:
            del self.app.playlists[name]
            self.app._save_user_data()

    def play_playlist(self, name):
        self.app.play_playlist(name)

    # ── Queue ──
    def get_queue(self):
        a = self.app
        out = []
        for t in a.queue:
            art_b64 = _get_art_b64(t, a.download_dir)
            out.append({'title': t['title'], 'artist': t['artist'], 'art_b64': art_b64})
        return {'queue': out, 'idx': a.current_queue_idx}

    # ── Settings ──
    def get_settings(self):
        return self.app.settings

    def save_setting(self, key, val):
        self.app.settings[key] = val
        self.app._save_user_data()


# ─── IMAGE HELPERS ─────────────────────────────────────────────────────────────
def _img_to_b64(path, size=(56, 56)):
    try:
        img = Image.open(path).convert('RGB').resize(size, Image.Resampling.LANCZOS)
        buf = BytesIO()
        img.save(buf, 'JPEG', quality=75)
        return base64.b64encode(buf.getvalue()).decode()
    except:
        return None

def _get_art_b64(track, download_dir, size=(56, 56)):
    base = os.path.splitext(os.path.basename(track['path']))[0]
    jpg = os.path.join(download_dir, f"{base}.jpg")
    if os.path.exists(jpg):
        return _img_to_b64(jpg, size)
    return None


# ─── CORE APP ──────────────────────────────────────────────────────────────────
class MelodiaApp:
    def __init__(self):
        self.yt_api = YTMusic()
        pygame.mixer.init()

        self.current_position = 0.0
        self.last_update_time = time.time()
        self.track_duration = 0
        self.is_playing = False
        self.is_paused = False
        self.is_scrubbing = False
        self.is_switching_track = False

        self.current_title = 'Nothing playing'
        self.current_artist = '—'
        self._cached_lyrics = None

        self.download_dir = os.path.join(os.path.expanduser('~'), 'Music', 'MelodiaDownloads')
        os.makedirs(self.download_dir, exist_ok=True)

        self.settings_file = os.path.join(self.download_dir, 'settings.json')
        self.playlists_file = os.path.join(self.download_dir, 'playlists.json')
        self.favorites_file = os.path.join(self.download_dir, 'favorites.json')

        self.settings = {'run_in_background': True, 'auto_play': True}
        self.playlists = {}
        self.favorites = []
        self._load_user_data()

        self.queue = []
        self.current_queue_idx = -1

        self.rpc = None
        self.discord_connected = False
        if HAS_DISCORD:
            threading.Thread(target=self._init_discord_rpc, daemon=True).start()

        # Start playback monitor
        threading.Thread(target=self._playback_monitor_loop, daemon=True).start()

    def _load_user_data(self):
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file) as f: self.settings.update(json.load(f))
            if os.path.exists(self.playlists_file):
                with open(self.playlists_file) as f: self.playlists = json.load(f)
            if os.path.exists(self.favorites_file):
                with open(self.favorites_file) as f: self.favorites = json.load(f)
        except Exception as e:
            print('Load error:', e)

    def _save_user_data(self):
        try:
            with open(self.settings_file, 'w') as f: json.dump(self.settings, f)
            with open(self.playlists_file, 'w') as f: json.dump(self.playlists, f)
            with open(self.favorites_file, 'w') as f: json.dump(self.favorites, f)
        except Exception as e:
            print('Save error:', e)

    # ── Recommendations ──
    def get_recommendations(self):
        try:
            files = [f for f in os.listdir(self.download_dir) if f.endswith('.mp3')]
            if files:
                seed = random.choice(files).replace('.mp3', '').replace('-', ' ')
                res = self.yt_api.search(seed, filter='songs', limit=1)
                if res and 'videoId' in res[0]:
                    watch = self.yt_api.get_watch_playlist(videoId=res[0]['videoId'], limit=15)
                    tracks = watch.get('tracks', [])[1:13]
                    return self._format_tracks(tracks)
            results = self.yt_api.search('Top Hits Trending', filter='songs', limit=12)
            return self._format_tracks(results)
        except Exception as e:
            print('Rec error:', e)
            return []

    def get_more_recommendations(self):
        try:
            files = [f for f in os.listdir(self.download_dir) if f.endswith('.mp3')]
            if files:
                seed = random.choice(files).replace('.mp3', '').replace('-', ' ')
                res = self.yt_api.search(seed, filter='songs', limit=1)
                if res and 'videoId' in res[0]:
                    watch = self.yt_api.get_watch_playlist(videoId=res[0]['videoId'], limit=10)
                    return self._format_tracks(watch.get('tracks', [])[1:7])
            results = self.yt_api.search('Trending Music', filter='songs', limit=6)
            return self._format_tracks(results)
        except Exception as e:
            print('More rec error:', e)
            return []

    def _format_tracks(self, tracks):
        out = []
        for t in tracks:
            thumb_list = t.get('thumbnails') or t.get('thumbnail') or []
            thumb = thumb_list[-1].get('url') if isinstance(thumb_list, list) and thumb_list else None
            out.append({
                'title': t.get('title', 'Unknown')[:40],
                'artist': (t.get('artists') or [{}])[0].get('name', 'Unknown'),
                'video_id': t.get('videoId', ''),
                'thumb': thumb,
            })
        return out

    # ── Playback ──
    def play_track(self, track_data):
        self.is_switching_track = True
        try:
            pygame.mixer.music.stop()
            pygame.mixer.music.unload()
            try:
                audio = MP3(track_data['path'])
                self.track_duration = audio.info.length
            except:
                self.track_duration = 180
            self.current_position = 0.0
            self.last_update_time = time.time()
            pygame.mixer.music.load(track_data['path'])
            pygame.mixer.music.play()
            self.is_playing = True
            self.is_paused = False
            
            # Save all track values inside the app instance variables safely
            self.current_title = track_data.get('title', 'Unknown')
            self.current_artist = track_data.get('artist', 'Unknown')
            
            # Store image assets securely so your existing state interval loop reads them
            self.current_art_b64 = track_data.get('art_b64', track_data.get('artwork', ''))
            self.current_thumbnail = track_data.get('thumbnail', track_data.get('cover_url', ''))
            
            self._cached_lyrics = None
            self._update_discord_status()

            # Fetch lyrics async (Your existing working logic)
            threading.Thread(target=self._fetch_lyrics, args=(track_data,), daemon=True).start()
        except Exception as e:
            print(f'Play error: {e}')
        finally:
            self.is_switching_track = False

    def queue_and_play(self, track_data):
        self.queue = [track_data]
        self.current_queue_idx = 0
        self.play_track(track_data)

    def add_to_queue(self, track_data):
        self.queue.append(track_data)

    def play_next(self):
        """Play next song in queue, or random from library if no next song"""
        if not self.queue or self.current_queue_idx >= len(self.queue) - 1:
            # No next song in queue - try to pick a random one
            files = [f for f in os.listdir(self.download_dir) if f.endswith('.mp3')]
            if files:
                # Exclude current song if possible
                current_file = None
                if self.queue and self.current_queue_idx >= 0:
                    current_track = self.queue[self.current_queue_idx]
                    current_file = os.path.basename(current_track['path'])
                
                available = [f for f in files if f != current_file] if current_file else files
                if available:
                    f = random.choice(available)
                    base = os.path.splitext(f)[0]
                    parts = base.split('-')
                    title = parts[0].strip()
                    artist = parts[1].strip() if len(parts) > 1 else 'Unknown'
                    track = {'title': title, 'artist': artist,
                             'path': os.path.join(self.download_dir, f),
                             'img_url': None, 'video_id': None}
                    self.queue_and_play(track)
                    return
            self.stop_music()
            return
        self.current_queue_idx += 1
        self.play_track(self.queue[self.current_queue_idx])

    def play_prev(self):
        if not self.queue or self.current_queue_idx <= 0:
            if self.queue: self.play_track(self.queue[self.current_queue_idx])
            return
        self.current_queue_idx -= 1
        self.play_track(self.queue[self.current_queue_idx])

    def toggle_pause(self):
        if not self.is_playing: return
        if self.is_paused:
            pygame.mixer.music.unpause()
            self.last_update_time = time.time()
        else:
            pygame.mixer.music.pause()
        self.is_paused = not self.is_paused
        self._update_discord_status()

    def seek(self, seconds):
        if not self.is_playing: return
        if seconds >= self.track_duration:
            self._trigger_track_advance()
            return
        pygame.mixer.music.stop()
        pygame.mixer.music.load(self.queue[self.current_queue_idx]['path'])
        pygame.mixer.music.play(start=float(seconds))
        if self.is_paused:
            pygame.mixer.music.pause()
        self.current_position = seconds
        self.last_update_time = time.time()

    def stop_music(self):
        pygame.mixer.music.stop()
        self.is_playing = False
        self.is_paused = False
        self.current_position = 0.0
        self.current_title = 'Nothing playing'
        self.current_artist = '—'
        self._update_discord_status()

    def jump_to_queue_index(self, index):
        if 0 <= index < len(self.queue):
            self.current_queue_idx = index
            self.play_track(self.queue[index])

    def remove_from_queue(self, index):
        if 0 <= index < len(self.queue):
            del self.queue[index]
            if index < self.current_queue_idx:
                self.current_queue_idx -= 1

    def play_playlist(self, name):
        files = self.playlists.get(name, [])
        if not files: return
        self.stop_music()
        self.queue = []
        for f in files:
            full = os.path.join(self.download_dir, f)
            if not os.path.exists(full): continue
            base = os.path.splitext(f)[0]
            parts = base.split('-')
            title = parts[0].strip()
            artist = parts[1].strip() if len(parts) > 1 else 'Unknown'
            self.queue.append({'title': title, 'artist': artist, 'path': full, 'img_url': None, 'video_id': None})
        if self.queue:
            self.current_queue_idx = 0
            self.play_track(self.queue[0])

    def handle_cloud_play(self, video_id, title, artist, image_url):
        safe = ''.join(c for c in f'{title} - {artist}' if c.isalnum() or c in (' ', '-', '_')).strip()
        mp3 = os.path.join(self.download_dir, f'{safe}.mp3')
        jpg = os.path.join(self.download_dir, f'{safe}.jpg')
        track = {'title': title, 'artist': artist, 'path': mp3, 'img_url': image_url, 'video_id': video_id}
        if os.path.exists(mp3):
            self.queue_and_play(track)
        else:
            self.current_title = 'Downloading…'
            self.current_artist = title
            threading.Thread(target=self._download_worker, args=(video_id, safe, mp3, jpg, track), daemon=True).start()

    def _download_worker(self, video_id, safe_name, mp3_path, jpg_path, track_data):
        try:
            if track_data.get('img_url'):
                req = urllib.request.Request(track_data['img_url'], headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=5) as r, open(jpg_path, 'wb') as f:
                    f.write(r.read())
            opts = {
                'format': 'bestaudio/best',
                'outtmpl': os.path.join(self.download_dir, safe_name + '.%(ext)s'),
                'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3', 'preferredquality': '192'}],
                'quiet': True, 'no_warnings': True,
            }
            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download([f'https://music.youtube.com/watch?v={video_id}'])
            self.queue_and_play(track_data)
        except Exception as e:
            print(f'Download error: {e}')
            self.current_title = 'Download failed'
            self.current_artist = '—'

    def _fetch_lyrics(self, track_data):
        self._cached_lyrics = "Loading lyrics..."
      
        if 'window' in globals():
            window.evaluate_js("updateLyrics('Loading lyrics...');")

        try:
            vid = track_data.get('video_id')
            if not vid:
                res = self.yt_api.search(f"{track_data['title']} {track_data['artist']}", filter='songs', limit=1)
                if res:
                    vid = res[0].get('videoId')
            
            if vid:
                watch = self.yt_api.get_watch_playlist(videoId=vid)
                lid = watch.get('lyrics')
                if lid:
                    self._cached_lyrics = self.yt_api.get_lyrics(lid).get('lyrics', 'No lyrics found.')
                else:
                    self._cached_lyrics = 'Instrumental or no lyrics found.'
            else:
                self._cached_lyrics = 'Could not identify track for lyrics.'
        except Exception:
            self._cached_lyrics = 'Failed to load lyrics.'
            
        # 3. DIRECT PUSH: Instantly force-feed the text to the DOM layout
        try:
            if 'window' in globals() and window:
                safe_lyrics_json = json.dumps(self._cached_lyrics)
                
                window.evaluate_js(f"updateLyrics({safe_lyrics_json});")
        except Exception as e:
            print(f"Failed to push lyrics to UI: {e}")

    def _playback_monitor_loop(self):
        while True:
            time.sleep(0.2)
            if self.is_playing and not self.is_paused and not self.is_scrubbing and not self.is_switching_track:
                if pygame.mixer.music.get_busy():
                    now = time.time()
                    self.current_position += now - self.last_update_time
                    self.last_update_time = now
                    if self.current_position >= self.track_duration and self.track_duration > 0:
                        self._trigger_track_advance()
                else:
                    if self.current_position > 1.0:
                        self._trigger_track_advance()
            else:
                self.last_update_time = time.time()

    def _trigger_track_advance(self):
        """Called when a track finishes - advances to next or picks random"""
        self.is_switching_track = True
        pygame.mixer.music.stop()
        try:
            pygame.mixer.music.unload()
        except:
            pass
        self.current_position = 0.0
        
        if not self.queue or self.current_queue_idx >= len(self.queue) - 1:
            # End of queue - pick a random song or stop
            if self.settings.get('auto_play', True):
                files = [f for f in os.listdir(self.download_dir) if f.endswith('.mp3')]
                # Exclude current song to avoid repetition
                current_file = None
                if self.queue and self.current_queue_idx >= 0:
                    current_track = self.queue[self.current_queue_idx]
                    current_file = os.path.basename(current_track['path'])
                
                available = [f for f in files if f != current_file] if current_file else files
                if available:
                    f = random.choice(available)
                    base = os.path.splitext(f)[0]
                    parts = base.split('-')
                    title = parts[0].strip()
                    artist = parts[1].strip() if len(parts) > 1 else 'Unknown'
                    track = {'title': title, 'artist': artist,
                             'path': os.path.join(self.download_dir, f),
                             'img_url': None, 'video_id': None}
                    self.is_switching_track = False
                    self.queue_and_play(track)
                    return
            self.stop_music()
            self.is_switching_track = False
            return
        
        self.is_switching_track = False
        self.play_next()

    # ── Discord ──
    def _init_discord_rpc(self):
        if not HAS_DISCORD: return
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self.rpc = Presence(DISCORD_APP_CLIENT_ID)
            self.rpc.connect()
            self.discord_connected = True
        except Exception as e:
            print(f'Discord RPC: {e}')

    def _update_discord_status(self):
        if not getattr(self, 'discord_connected', False) or not self.rpc: return
        try:
            if not self.queue or self.current_queue_idx < 0:
                self.rpc.clear(); return
            track = self.queue[self.current_queue_idx]
            if self.is_playing and not self.is_paused:
                self.rpc.update(details=track['title'][:127],
                                state=f"by {track['artist']}"[:127],
                                start=int(time.time() - self.current_position),
                                large_image='logo', large_text='Melodia')
            elif self.is_paused:
                self.rpc.update(details=f"Paused: {track['title']}"[:127],
                                state=f"by {track['artist']}"[:127],
                                large_image='logo')
            else:
                self.rpc.clear()
        except Exception as e:
            print(f'Discord update: {e}')

    def show_main_window(self):
        if getattr(self, 'window', None):
            self.window.show()
            self.window.restore()
    # ── System tray ──
    def _init_system_tray(self, window=None):
        if not HAS_TRAY: return
        try:
            img = Image.new('RGB', (64, 64), (29, 185, 84))
            draw = ImageDraw.Draw(img)
            draw.ellipse((16, 16, 48, 48), fill=(255, 255, 255))
            
            def show_window():
                if window:
                    window.show()
                    window.restore()
            
            menu = (
                item('Play/Pause', lambda: self.toggle_pause()),
                item('Next', lambda: self.play_next()),
                item('Show Window', show_window, default=True),
                item('Exit', lambda: os._exit(0))
            )
            self.tray_icon = pystray.Icon('Melodia', img, 'Melodia', menu)
            threading.Thread(target=self.tray_icon.run, daemon=True).start()
        except Exception as e:
            print(f'Tray: {e}')

    def _init_media_keys(self):
        if not HAS_KEYBOARD: return
        try:
            keyboard.add_hotkey('play/pause media', self.toggle_pause)
            keyboard.add_hotkey('next track', self.play_next)
            keyboard.add_hotkey('previous track', self.play_prev)
        except Exception as e:
            print(f'Media keys: {e}')


if __name__ == '__main__':
    app = MelodiaApp()
    api = MelodiaAPI(app)

    app._init_media_keys()

    window = webview.create_window(
        'Melodia',
        html=HTML,
        js_api=api,
        width=1200,
        height=780,
        min_size=(900, 620),
        background_color='#0a0a12',
        frameless=False
    )

    # Initialize system tray with window reference
    app._init_system_tray(window)

    def on_closing():
        if app.settings.get('run_in_background', True):
            window.hide()
            return False
        else:
            return True 

    window.events.closing += on_closing
    # ──────────────────────────────

    webview.start()