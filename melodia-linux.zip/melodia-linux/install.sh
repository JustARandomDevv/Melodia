#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────
# Melodia — Linux Mint (Cinnamon) setup script
#
# This does NOT modify main.py in any way. It only installs the system
# libraries and Python packages that main.py's unmodified imports need
# in order to run on Linux Mint, then sets up a proper app launcher.
# ─────────────────────────────────────────────────────────────────────────
set -e

echo "== Melodia setup for Linux Mint (Cinnamon) =="

# 1. System packages
#    - webkit2gtk + python3-gi + gir bindings: required by pywebview's GTK backend
#      (pywebview uses this automatically on Linux; no code change needed)
#    - ffmpeg: required by yt-dlp (audio extraction) and mutagen-friendly playback
#    - python3-venv/pip: for an isolated environment
#    - gir1.2-appindicator3 (or ayatana variant): required for pystray's tray icon
#      to actually show up under Cinnamon, which uses AppIndicators rather than
#      the legacy Xembed tray
echo "-- Installing system packages (requires sudo) --"
sudo apt update
sudo apt install -y \
    python3 python3-venv python3-pip python3-dev \
    python3-gi python3-gi-cairo gir1.2-gtk-3.0 \
    gir1.2-webkit2-4.1 || sudo apt install -y gir1.2-webkit2-4.0 \
    ffmpeg \
    libjpeg-dev zlib1g-dev \
    gir1.2-appindicator3-0.1 || sudo apt install -y gir1.2-ayatanaappindicator3-0.1

# 2. Python virtual environment (keeps things isolated from system Python)
echo "-- Creating virtual environment (.venv) --"
python3 -m venv --system-site-packages .venv
source .venv/bin/activate

# --system-site-packages lets the venv see the apt-installed python3-gi /
# gi.repository bindings above, since those aren't pip-installable.

# 3. Python dependencies
echo "-- Installing Python packages --"
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "== Setup complete =="
echo "Run the app with:"
echo "    source .venv/bin/activate && python3 main.py"
echo ""
echo "Or install the desktop launcher with: ./install-launcher.sh"
